
// use std::io;
// use std;

// fn helloWorld() {

fn hello_world() {
	println!("Hello World! Welcome To Rust!!!");
}

// warning: function `helloWorld` should have a snake case name
//  --> RustConcepts.rs:2:4
//   |
// 2 | fn helloWorld() {
//   |    ^^^^^^^^^^ help: convert the identifier to snake case: `hello_world`

// let number = 999;
   // | ^^^
   // | |
   // | `let` cannot be used for global variables

fn play_with_ifelse() {
	let condition = true;

	// In Rust
	//		if-else Is An Expression
	//				Expression Is A Statement Having Retun Value
	let number = if condition { 5 } else { 6 };
	// Embedding Value Of Variable In String Using {}
	println!("The Value Of Number: {number}");
	// In C/C++/Java : Equivalent Code Is As Follows
	// int number = (condition) ? 5 :  6 ;

	// In C/C++/Java : Equivalent Code Can't Be Done With if-else
	// 		if-else A Statement
	// int number = if (condition) { 
	// 		5 
	// } else { 
	// 		6 
	// };

	// if-else Is An Expression Value Will Be Either if-Expression Or else-Expression
	//		if Expression = Last Expression Value Inside if-Block 
	//		else Expression = Last Expression Value Inside else-Block

	let number_again = if condition { 
		let _ = 5 + 10 ; 	// Statement
		// 200
		let x = 100 + 200; 	// Statement 
		x + 300 + 900 		// Expression
		// 10
		// let _ = 99 ;
	} else { 		
		let _ = 6 - 10 ; // _ Is Name Of Variable To Ignore It 
		111 + 222 	// Expression
	};	

	//______________________________________________________

	// `if` and `else` have incompatible types

	// Function : play_with_ifelse
	// The Value Of Number: 5
	// The Value Of number_again: 300

	// Embedding Value Of Variable In String Using {}
	println!("The Value Of number_again: {number_again}");

	//___________________________________________________

	let x = -10;

	let something = if x == 10 { 		
		println!("If Branch Executed");
	} else {
		println!("Else Branch Executed");		
		// 999 // Error: ^^^ expected `()`, found integer
	};

	println!("Value something = {:?}", something);

	//___________________________________________________

	let something1 = if x == 10 { 		
		111 // Expression 
	} else {
		222
	};

	println!("Value something1 = {:?}", something1 );

	// Value something 	= () 	- Unit Value
	// Value something1 = ()	- Unit Value

	// [ 1 0 ]
	// [ 0 1 ]  2 x 2 

	// In C/C++/Java/Python
	//		Every Zero Int Value Is False and Non-Zero True
	//			int Value Implicitly Coverted To Boolean Value
	//		if ( Expression ) { } else { }
	//				Here Expression Can Be Anything Which Evaluates To Int Value


	// In Rust
	//		if ( Expression ) { } else { }
	//				Here Expression Is Boolean Expression
	//		int Value Implicitly Does't Covert To Boolean Value

	// Conversion Should Happen in Following Steps
	//			1. First Type Conversion Happens 
	//			2. Than Value Conversion

	// if x = 10 { 		// |        ^ expected `bool`, found integer

	if x == 10 { 		
		println!("If Branch Executed");
	} else {
		println!("Else Branch Executed");		
	}
}

// Function : play_with_ifelse
// The Value Of Number: 5

//_____________________________________________________________

// let guess = "Some Number"
    // | ^^^
    // | |
    // | `let` cannot be used for global variables
    // | help: consider using `static` or `const` instead of `let`

fn play_with_shadowing() {
//		Happens At Compile Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable
	let guess = "Good Evening!!!";
	println!("Guess Value: {guess}");

	// Shadowing Previous Defintions
	let guess = "Guten Tag!!!";
	println!("Guess Value: {guess}");	

	// With let Keyword You Are Creating Immutable State
	let guess = 99; 	
	println!("Guess Value: {guess}");	

	// error[E0384]: cannot assign twice to immutable variable `guess`
	// guess = 100;
	// println!("Guess Value: {guess}");

	// Mutating State
	//		Intent To Programmer Clear
	// let greeting = "Good Morning!";

	// Mutability Should Be Based On Small Local Context/Reason/Purpose Over
	let mut greeting = "Good Morning!";
	println!("Greeting: {greeting} ");

	greeting = "Good Night!";
	println!("Greeting: {greeting} ");	

	// Go Back To IMMutability Movment Local Context/Reason/Purpose Over
	let greeting = "Good Good Morning Morning!!!";
	println!("Greeting: {greeting} ");	

	// greeting = "Gooddddddd!";
	// ^^^^^^^^^^^^^^^^^^^^^^^^ cannot assign twice to immutable variable

	// Outside Context
	let x = 5;
	let x = x + 1;

	println!("Outside Value: {x}" );

	{ // Local Socpe, Inside Context
		// Inside Context Always Supercede Outside Context
		// Shadow Outer x 
		let x = x * 2;
		println!("Outside Value: {x}" );
	}	
}

//	SYSTEM PRINCIPLE
//		PREDICTABLE AND PROVABLE

// 	DESIGN PRINCIPLE
//		 Design Towards IMMutability Rather Than Towards Mutability

// In C/C++/Java/Python
//		Mutability Is Default

//		String greeting = new String(); // greeting is Mutable By Default

// In Rust
//		IMMutability Is Default

// int a = 100;
// a = 100

// Function : play_with_shadowing
// Guess Value: Good Evening!!!
// Guess Value: Guten Tag!!!

// Static Languages
//		C/C++/Java/Rust
//		Most Of The Decisions Are Done At Compile Time
//		Happens At Compile Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable

// Dynamic Languages
//		Python/Ruby/Objective-C/JavaScript
//		Most Of The Decisions Are Done At Run Time
//		Happens At Run Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable

//_____________________________________________________________


// PLEASE DO HANDS EXPERIMENT ON ABOVE CODE!!! 
// MOMENT DONE RAISE YOUR HANDS!!!

fn play_with_static() {
	// Type Annotation Is Explicit 
	static SOME: i32 = 99;

	// static mut some: i32 = 99;
	//	error[E0133]: use of mutable static is unsafe and requires unsafe function or block
	//		   = note: mutable statics can be mutated by multiple threads: 
	//				aliasing violations or data races will cause undefined behavior

	println!("Value some : {SOME}" );
	// some  = 99; // Error: ^^^^^^^^^^ cannot assign
}

//_____________________________________________________________

fn play_with_type_inferrencing() {
	// Type Inferred Implicity
	//		Happens At Compile Time
	//			1. Type Inferrencing : From RHS Value
	//			2. Type Binding 	 : Binded To LHS Value/Variable

	let c = 'z';
	// Type Explicitly Annotated
	let z: char = 'Z';

	println!("Value: {c}" );
	println!("Value: {z}" );

	let x = -10;

	// What Is The Type Of something?		
	let something = if x == 10 { 
		println!("If Branch Executed");
		99
	} else {
		println!("Else Branch Executed");		
		// "Ding Dong" // ^^^^^^^^^^^ expected integer, found `&str`
		1000
	};

	println!("Value something = {:?}", something);
}

//_____________________________________________________________

// Table 3-1: Integer Types in Rust
// Length	Signed	Unsigned
// 8-bit	i8		u8
// 16-bit	i16		u16
// 32-bit	i32		u32
// 64-bit	i64		u64
// 128-bit	i128	u128

// arch	isize	usize

// Table 3-2: Integer Literals in Rust

// Number literals	Example
// Decimal			98_222
// Hex				0xff
// Octal			0o77
// Binary			0b1111_0000
// Byte (u8 only)	b'A'

#[allow(unused)]
fn play_with_types() {
    // In C/C++/Java By Default It's double Type
    // In Rust double is Equivalent to f64
    let x = 98.98; //f64

    // Explicitly Annotating To Make It f32
    let y: f32 = 3.0; // f32

    // addition
    let sum = 5 + 10; // i64

    // subtraction
    let difference = 95.5 - 4.3;

    // multiplication
    let product = 4 * 30;

    // division
    let quotient = 56.7 / 32.2;
    let truncated = -5 / 3; // Results in -1

    // remainder
    let remainder = 43 % 5;

    // Rust char Type Is Unicode Character Type
    // In C/C++ char Is ASCII Character

	let c = 'z';
	// Type Explicitly Annotated
	let z: char = 'Z';
	let zz: char = '😊';

	println!("Value: {c}" );
	println!("Value: {z}" );
	println!("Value: {zz}" );

	// Tuple: Associated Values
	// What Is The Type tup?
		// tup Type Is Tuple Of Types (i64, f64, i64)
		// tup1 Type Is Tuple Of Types (i32, f64, u8)

	let tup: (i64, f64, i64) = (100, 89.89, 1);
	let tup1: (i32, f64, u8) = (100, 89.89, 1);

	// tup1 = tup;
	// ^^^ expected `(i32, f64, u8)`, found `(i64, f64, i64)`

	// Tuple Unpacking: Means Assinging Tuple Members To Variables At LHS
	let (x, y, z) = tup;
	println!("Tuple Value : {x} {y} {z}");

	let (_, yy, _) = tup;
	println!("Tuple Value : {yy}");

	let t1 = tup.0;
	let t2 = tup.1;
	let t3 = tup.2;	
	println!("Tuple Value : {t1} {t2} {t3}");

	let xx: i32 = 90;
	let zz: i64 = 100;
	// In Rust Most Of The Things Are Explicitly Type Converted
	let tt = xx + zz; // Error: ^^ expected `i32`, found `i64`
}

// Function : play_with_types
// Value: z
// Value: Z
// Value: 😊

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	// println!("\nFunction : helloWorld");
	// helloWorld();

	println!("\nFunction : hello_world");
	hello_world();

	println!("\nFunction : play_with_ifelse");
	play_with_ifelse();

	println!("\nFunction : play_play_with_charwith_shadowing");
	play_with_shadowing();

	println!("\nFunction : play_with_static");
	play_with_static();

	println!("\nFunction : play_with_type_inferrencing");
	play_with_type_inferrencing();

	println!("\n\nFunction : play_with_types");
	play_with_types()

	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}

