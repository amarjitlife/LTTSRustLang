
#include <stdio.h>

void play_with_shadowing() {
	char guess[] = "Good Evening!!!";
	printf("Guess Value: %s", guess);

// Experiments.c:8:14: error: redefinition of ‘guess’
	char guess[] = "Guten Tag!!!";
	printf("Guess Value: %s", guess);	
}


void main() {
	printf("\n Function : play_with_shadowing");
	play_with_shadowing();

	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
}
