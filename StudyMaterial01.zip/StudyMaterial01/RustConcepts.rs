
// use std::io;
// use std;

// fn helloWorld() {

fn hello_world() {
	println!("Hello World! Welcome To Rust!!!");
}

// warning: function `helloWorld` should have a snake case name
//  --> RustConcepts.rs:2:4
//   |
// 2 | fn helloWorld() {
//   |    ^^^^^^^^^^ help: convert the identifier to snake case: `hello_world`

fn play_with_ifelse() {
	let condition = true;

	// In Rust
	//		if-else Is An Expression
	//				Expression Is A Statement Having Retun Value
	let number = if condition { 5 } else { 6 };
	// In C/C++/Java : Equivalent Code Is As Follows
	// int number = (condition) ? 5 :  6 ;

	// In C/C++/Java : Equivalent Code Can't Be Done With if-else
	// 		if-else A Statement
	// int number = if (condition) { 
	// 		5 
	// } else { 
	// 		6 
	// };

	// Embedding Value Of Variable In String Using {}
	println!("The Value Of Number: {number}");

	// if-else Is An Expression Value Will Be Either if-Expression Or else-Expression
	//		if Expression = Last Expression Value Inside if-Block 
	//		else Expression = Last Expression Value Inside else-Block

	let number_again = if condition { 
		let _ = 5 + 10 ; 	// Statement
		// 200
		let x = 100 + 200; 	// Statement 
		x + 300 + 900 		// Expression
		// let _ = 99 ;
	} else { 		
		let _ = 6 - 10 ;
		111 + 222 	// Expression
	};	

	// `if` and `else` have incompatible types

	// Function : play_with_ifelse
	// The Value Of Number: 5
	// The Value Of number_again: 300

	// Embedding Value Of Variable In String Using {}
	println!("The Value Of number_again: {number_again}");

	// In C/C++/Java/Python
	//		Every Zero Int Value Is False and Non-Zero True
	//			int Value Implicitly Coverted To Boolean Value
	//		if ( Expression ) { } else { }
	//				Here Expression Can Be Anything Which Evaluates To Int Value

	let x = -10;

	// In Rust
	//		if ( Expression ) { } else { }
	//				Here Expression Is Boolean Expression
	//		int Value Implicitly Does't Covert To Boolean Value

	// Conversion Should Happen in Following Steps
	//			1. First Type Conversion Happens 
	//			2. Than Value Conversion

	if x = 10 { 		// |        ^ expected `bool`, found integer
		println!("If Branch Executed");
	} else {
		println!("Else Branch Executed");		
	}

}

// Function : play_with_ifelse
// The Value Of Number: 5


fn main() {
	// println!("\nFunction : helloWorld");
	// helloWorld();

	println!("\nFunction : hello_world");
	hello_world();

	println!("\nFunction : play_with_ifelse");
	play_with_ifelse();


	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
	// println!("\nFunction : ");
}

