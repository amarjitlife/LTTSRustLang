
fun playWithIfElse() {
	let condition = true
	
	let number = if (condition) 10 else 20
	println("Value: $number")

	let number = if (condition) {
		10
		100 + 200  
	} else { 
		20
		111 + 222
	}
	
	println("Value: $number")

}


fun main() {
	println("\nFunction : playWithIfElse")
	playWithIfElse()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

