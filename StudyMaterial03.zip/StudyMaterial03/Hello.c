
#include <stdio.h>

void main() {
	printf("\nHello World! Welcome To C!!!");
}


