// #![allow(unused)]

//_____________________________________________________________

struct User {
	active: bool,
	username: String,
	email: String,
	sign_in_count: u64,
}

fn play_with_user() {

	let user = User {
		active: true,
		username: 	String::from("Rock Star"),
		email: 		String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user.active, user.username, 
		user.email, user.sign_in_count );	

//	user.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign

	let mut user1 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	user1.email = "rockstar@yahoo.com".to_string();			
	// let mut user1.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign

	// let someting.some = "Ting Tong";

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	// Can Change Member Orders While Creating Variable Of Type Struct e.g. User Struct
	let user2 = User {
		username: String::from("Rock Star"),
		active: true,
		sign_in_count: 1,
		email: String::from("rockstar@gmail.com"),
	};

	println!("Data : {} {} {} {}", user2.active, user2.username, 
		user2.email, user2.sign_in_count );	

	// let user3 = User {
	// 	active : true, // error: expected `:`, found `=`
	// 	username: "Rock Star",
   // |                   ^^^^^^^^^^^- help: try using a conversion method: `.to_string()`
   // |                   |
   // |                   expected `String`, found `&str`
	// 	email: 	  "rockstar@gmail.com",
	// 	sign_in_count: 1,
	// };

	let user4 = User {
		active: false,
		username: user1.username,
		email: user1.email,
		sign_in_count: user1.sign_in_count,
	};

	println!("Data : {} {} {} {}", user4.active, user4.username, 
		user4.email, user4.sign_in_count );	

	let user5 = User {
		active: false,
		..user2 // Assigns user2 member values to user5 remaining members 
	};

	println!("Data : {} {} {} {}", user5.active, user5.username, 
		user5.email, user5.sign_in_count );	


	let user3 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	let user6 = user3;
	println!("Data : {} {} {} {}", user6.active, user6.username, 
		user6.email, user6.sign_in_count );	

	let mut user7 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user7.active = false;
	println!("Data : {} {} {} {}", user7.active, user7.username, 
		user7.email, user7.sign_in_count );		

	let user8: User;

	user8 = user7;
	println!("Data : {} {} {} {}", user8.active, user8.username, 
		user8.email, user8.sign_in_count );		

	let mut user9 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user9.active = false;
	println!("Data : {} {} {} {}", user9.active, user9.username, 
		user9.email, user9.sign_in_count );		

}

//_____________________________________________________________

fn build_user( email: String, username: String ) -> User {
	User {
		active: true,
		username: username,
		email: email,
		sign_in_count: 1,
	}
}

fn build_user_better( email: String, username: String ) -> User {
	User {
		active: true,
		// Short Cut Notion When Variable Names Are Same As Member Names
		username,
		email,
		sign_in_count: 1,
	}
}

fn play_with_build_user() {

	let mansa = build_user( String::from("mansa@gmail.com"), String::from("Mansa Tell"));

	println!("Data : {} {} {} {}", mansa.active, mansa.username, 
		mansa.email, mansa.sign_in_count );		

	let mansa1 = build_user_better( String::from("mansa@gmail.com"), String::from("Mansa Tellis"));

	println!("Data : {} {} {} {}", mansa1.active, mansa1.username, 
		mansa1.email, mansa1.sign_in_count );		
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_user");
	play_with_user();

	println!("\n\n\nFunction : play_with_build_user");
	play_with_build_user();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

