#![allow(unused)]

//______________________________________________________________

fn largest_i32( list: &[i32] ) -> &i32 {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn largest_char(list: &[char]) -> &char {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn play_with_largest() {
    let number_list = vec![34, 50, 25, 100, 65];

    let result = largest_i32(&number_list);
    println!("The largest number is {result}");

    let char_list = vec!['y', 'm', 'a', 'q'];

    let result = largest_char(&char_list);
    println!("The largest char is {result}");
}

//______________________________________________________________

// What Is Template/Generics??
//		Generic : Code Which Will Generate Code
//			Code Generation Happens At Compile Time

// T Is Type Placeholder
//		Type PlaceHolder Will Get Substituted With Type At Compile Time
//			Compiler Will Susbtitute It!

/*
// <T> Means Telling Compiler Treat T As Type PlaceHolder
//		Hence T Substitued With i32
// Following Code Is Generated
fn largest_i32(list: &[i32]) -> &i32 {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }
    largest
}

//	Hence T Substitued With char
// Following Code Is Generated
fn largest_char(list: &[char]) -> &char {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }
    largest
}
*/

// Template Of Code
//		Type PlaceHolder Without Bounded Type
//			Hence T Can Be Substited With Any Type
// fn largest<T>(list: &[T]) -> &T {

//		Type PlaceHolder With Bounded Type
//		Type Bounds
//			Hence T Can Be Substited With Only Types Which Implements PartialOrd

// GENERIC FUNCTION
fn largest<T: std::cmp::PartialOrd>(list: &[T]) -> &T {
    let mut largest = &list[0];

    for item in list {
        if item > largest { 
        	// error[E0369]: binary operation `>` cannot be applied to type `&T`
            largest = item;
        }
    }
    largest
}

fn play_with_largest_generic() {
    // let number_list: [i32] = vec![34, 50, 25, 100, 65];
    let number_list = vec![34, 50, 25, 100, 65];
    let result = largest( &number_list );
    println!("The largest number is {}", result);

    // let char_list: [char] = vec!['y', 'm', 'a', 'q'];
    let char_list = vec!['y', 'm', 'a', 'q'];
    let result = largest(&char_list);
    println!("The largest char is {}", result);
}

//______________________________________________________________

// GENERIC STRUCTURE

struct Point<T> {
    x: T,
    y: T,
}

// Compiler Will Generate Code For Following Usage
    // let integer = Point { x: 5, y: 10 };

    // struct Point_i32 {
    //     x: i32,
    //     y: i32,
    // }

// Compiler Will Generate Code For Following Usage
    // let float = Point { x: 1.0, y: 4.0 };

    // struct Point_f64 {
    //     x: f64,
    //     y: f64,
    // }

fn play_with_point_generic() {
    let integer = Point { x: 5, y: 10 }; // Inferred Type Is i32 Hence T PlaceHolder Will Be i32 
    let float = Point { x: 1.0, y: 4.0 }; // Inferred Type Is f64 Hence T PlaceHolder Will Be f64
}

//______________________________________________________________

struct Point1<T, U> {
    x: T,
    y: U,
}

// Compiler Will Generate Equivalent Code Based On Per Usage
// struct Point1_i32_i32 {
//     x: i32,
//     y: i32,
// }

// struct Point1_f64_f64 {
//     x: f64,
//     y: f64,
// }

// struct Point1_i32_f64 {
//     x: i32,
//     y: f64,
// }

fn play_with_point_generic_multiple() {
    let both_integer 		= Point1 { x: 5, y: 10 }; // T Will Be i32 and U Will Be i32
    let both_float 			= Point1 { x: 1.0, y: 4.0 }; // T Will Be f64 and U Will Be f64
    let integer_and_float 	= Point1 { x: 5, y: 4.0 }; // T Will Be i32 and U Will Be f64
}

//______________________________________________________________

struct Point2<T> {
    x: T,
    y: T,
}

// Generic Implementation Template For All T PlaceHolder Other Than f32
impl<T> Point2<T> {
	// Generic Method
    fn x(&self) -> &T {
        &self.x
    }
}

// Use Template When It's f32
impl Point2<f32> {
    fn distance_from_origin(&self) -> f32 {
        (self.x.powi(2) + self.y.powi(2)).sqrt()
    }
}

fn play_with_point_generic2() {
    let p = Point2 { x: 5, y: 10 };

    println!("p.x = {}", p.x());
}


//______________________________________________________________

struct Point3<X1, Y1> {
    x: X1,
    y: Y1,
}

impl<X1, Y1> Point3<X1, Y1> {
    fn mixup<X2, Y2>(self, other: Point3<X2, Y2>) -> Point3<X1, Y2> {
        Point3 {
            x: self.x,
            y: other.y,
        }
    }
}

fn play_with_point_generic3() {
    let p1 = Point3 { x: 5, y: 10.4 };
    let p2 = Point3 { x: "Hello", y: 'c' };

    let p3 = p1.mixup(p2);

    println!("p3.x = {}, p3.y = {}", p3.x, p3.y);
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_largest");
	play_with_largest();

	println!("\n\n\nFunction : play_with_largest_generic");
	play_with_largest_generic();

	println!("\n\n\nFunction : play_with_point_generic");
	play_with_point_generic();

	println!("\n\n\nFunction : play_with_point_generic_multiple");
	play_with_point_generic_multiple();

	println!("\n\n\nFunction : play_with_point_generic2");
	play_with_point_generic2();

	println!("\n\n\nFunction : play_with_point_generic3");
	play_with_point_generic3();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

