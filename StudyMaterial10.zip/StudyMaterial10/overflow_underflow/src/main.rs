
#[allow(arithmetic_overflow)]
fn play_with_overflow_underflow() {
    // let a: i8 = 128;
    let a: i8 = 127;
    let b: i8 = 10;

    // IN RUST:: Following Overflow/Underflow Checks Generated In Debug Mode
    // IN RUST:: Following Overflow/Underflow Checks WILL BE PART OF Release Mode

    // if (a > 0 && b > INT_MAX - a) {
    //     printf("Overflow Happening");
    //     return
    // } else if (a < 0 && b < INT_MIN - a) {
    //     printf("Overflow Happening");
    //     return 
    // }

    let c = a + b;
// ^^^^^ attempt to compute `i8::MAX + 10_i8`, which would overflow
    println!("Result : {c}");
}

fn main() {
	println!("\n\n\nFunction : play_with_overflow_underflow");
        play_with_overflow_underflow();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}


