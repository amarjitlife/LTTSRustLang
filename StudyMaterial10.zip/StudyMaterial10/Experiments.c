
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
//________________________________________________________

void play_with_shadowing() {
	char guess[] = "Good Evening!!!";
	printf("Guess Value: %s", guess);

// Experiments.c:8:14: error: redefinition of ‘guess’
	// char guess[] = "Guten Tag!!!";
	// printf("Guess Value: %s", guess);	
}

//________________________________________________________

void play_with_int_values() {
	int some = 32;
	// long some = 32;

	printf("\nsome Value: %ld", some );
	some = 3123456789;
	printf("\nsome Value: %ld", some );
}

// Function : play_with_int_values
// some Value: 32
// some Value: -1171510507

// Function : play_with_int_values
// some Value: 32
// some Value: 3123456789

//________________________________________________________

// OVERFLOW/UNDEFLOW HAPPENS IN THIS CODE
int unsafe_sum( int a, int b ) {
	return a + b;
}

// GOOD DESIGN
int sum_better(int a, int b) {
	
	if (a > 0 && b > INT_MAX - a) {
		printf("Overflow Happening");
		return 0; 
	} else if (a < 0 && b < INT_MIN - a) {
		printf("Overflow Happening");
		exit(1);
		// return 0; 
	}

	return a + b;
}
 
*/
//________________________________________________________

// fn say_greeting( ) -> String {
// fn say_greeting() -> () {

void say_greeting() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Reference Is Local To Function
	//		greeting Is Ownership Of "Guten Tag" Object Of String Type
	// let greeting = String::from("Guten Tag!!!");

	char * greeting = ( char * ) malloc( sizeof( "Guten Tag!!!" ) + 1 );
	strcpy( greeting, "Guten Tag!!!");
	greeting[12] = '\0';

	printf("String Value: %s", greeting);
	// BY DEFAULT 
	// 		On Exit From Local Scope Of Function/Local Context
	//				Life Time Of greeting Is Over

	// return greeting;
}

void play_with_function_arguments_again() {
	char got_greeting[13]; 
	say_greeting();
	printf("Greeting: %s", got_greeting);
}

//________________________________________________________


void play_with_array_and_pointers() {
	// Elligible Array Indexes Are 0 To 4 Inclusive
	int number[5] = { 10, 20, 30, 40, 50 };

	// Vunerability In Code
	int i = 0;
	for ( i = -10 ; i < 10 ; i++ ) {
		printf("\n a[%d] = %d", i, number[i] );
	}

	// In C/C++
	// Raw Pointers: Unsafe Pointers
	int *ptr = number;
	for ( i = -10 ; i < 10 ; i++ ) {
		printf("\n a[%d] = %d", i, *( ptr + i ) );
	}
}

//________________________________________________________

// Vunerability 02 In Code
// int sum( int a, int b ) {
// 		return a + b;
// }

/* UserName and Password Are Supplied*/ 
void aunthication_function( char username[], char password[]) {
	char username[] = username;
	char password[] = password;

	int number[5] = { 10, 20, 30, 40, 50 };

	// Vunerability 01 In Code
	// int index = sum_giving_index(a, b);
	int index = -10;
	for ( ; index < 5 ; index++ ) {
		printf("\n a[%d] = %d", index, number[index] );
	}
}

//________________________________________________________

// Write Following sum Function Code in C
//		It Should Return Valid Arithematic Sum Or Return Can't Calculate Sum

int error = 0;

int sum_better(int a, int b, int *error) {	
	if (a > 0 && b > INT_MAX - a) {
		*error = 1; 
	} else if (a < 0 && b < INT_MIN - a) {
		*error = 1; 
	}

	return a + b;
}

int result = sum_better( 909039043, 9093049304, &error );
if ( error == 0 ) {
	printf("Valid Result : %d", result);
}

//________________________________________________________

typedef result_type {
	int valid;
	int value; // Wrapped Inside Option Bucket 
} Option;

// API
Option sum_best(int a, int b ) {
	Option result = {0, 0};	
	if (a > 0 && b > INT_MAX - a) {
		result.valid = 0;
	} else if (a < 0 && b < INT_MIN - a) {
		result.valid = 0;
	}

	result.valid = 1;
	result.value = a + b;
}

Option result = sum_best(a, b);

// API Consumer
if ( result.valid ) {
	printf("Valid Result : %d", result.value);	
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design

//________________________________________________________

// In C++

int sum_exception(int a, int b) {	
	// Local State Is Local
	if (a > 0 && b > INT_MAX - a) {
		// BAD DESIGN
		//		It Breaks Encapsulation
		throw OverflowException;
	} else if (a < 0 && b < INT_MIN - a) {
		throw UnderflowException;
	}

	return a + b;
}

// if ( error == 0 ) {
// 	printf("Valid Result : %d", result);
// }

try {
	// User Of API sum
	//		Give Me Valid Or Tell Can't Give Valid Sum
	//			Why sum Can't Give Valid Sum????
	int result = sum_exception( 909039043, 9093049304 );
	printf("Valid Result : %d", result);
} catch( OverflowException ) {
	// Handling Code
} catch (UnderflowException ) {
	// Handling Code
}



//________________________________________________________
//________________________________________________________

void main() {
	// printf("\n\n\n Function : play_with_shadowing");
	// play_with_shadowing();

	// printf("\n\n\n Function : play_with_int_values");
	// play_with_int_values();

	printf("\n\n\n Function : play_with_function_arguments_again");
	play_with_function_arguments_again();

	printf("\n\n\n Function : play_with_array_and_pointers");
	play_with_array_and_pointers();

	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
}
