
//_____________________________________________________________

fn play_with_scope() { // Outer Scope Starts
	let greeting = "Good Evening!!!";
	println!("Hey: {greeting}");

	let hello = String::from("Hello More!!!");
	println!("Hey: {hello}");

	{ // Inside/Local Scope Starts
		// Inside Always Take Precedence Over Outer Scope
		//		Identifiers In Inside/Local Scope Shadow Outside/Outer Scope One
		let hello = "Hello!"; // LifeTime Of hello Till Scope Ends
		println!("Hey: {hello}");
	} // Inside/Local Scope Ends

// 	println!("Hey: {hello}");	
// // 14 |     println!("Hey: {hello}");    
// //    |                     ^^^^^ not found in this scope

	// Shadowing Identifiers In Same Scope
	let hello = String::from("Hello Once More!!!");
	println!("Hey: {hello}");

	let hello = 99898;
	println!("Hey: {hello}");

	let hello = String::from("Guten Tag!!!");
	println!("Hey: {hello}");
} // Outer Scope Ends

// Function : play_with_scope
// Hey: Good Evening!!!
// Hey: Hello Once More!!!
// Hey: Hello!

//_____________________________________________________________

fn play_with_scope_again() { // Outer Scope Starts
				// Allocated String Type Object At Heap
				//		greeting Is Refrence To String Type Object At Heap
				//		greeting Is Stored In Stack Frame 
				//				Of Context play_with_scope_again Function
	let greeting = String::from("Guten Tag!!!");
	println!("Hey: {greeting}");

	// 	Reference Assignment With Ownership Shfiting
	//		Ownership Of Object Is Shifted To hello
	// 		greeting Refrence Is Deprecated : No More Exists After This Assignment
	//			greeting Refrence Lifetime Is Over
	//		Hence You Can't Refer Object With greeting Reference
	let hello = greeting; 
	println!("Hey: {hello}");
	// println!("Hey: {greeting}"); // Error: Can't Refer Object With greeting Reference

	// Following Are Allocated At Stack
	let x = 10;
	let y = x; 	// Copy Semantics i.e. It Creates Duplicate Copy

	println!("Value x: {x}");
	println!("Value y: {y}");

	// Following Are Allocated At Stack
	//		String Literal Constant/Immutable i.e. Start and Ends Quotes ""
	let hi = "Hi, How are you?";
	let hiii = hi; // Copy Semantics

	println!("Value hi: {hi}");
	println!("Value hiii: {hiii}");	

	//__________________________________________
	
	let s1 = String::from("Dell Inc.");
	let s2 = s1; // Move Semantics :: Ownership Shifted

	// println!("Company: {s1}");
	println!("Company: {s2}");

	let s11 = String::from("Dell Corporation.");
	let s22 = s11.clone(); 	// Deep Copy i.e. s22 Points To Different Copy Of Object s11

	println!("Company: {s11}");
	println!("Company: {s22}");

} // Outer Scope Ends

//______________________________________________________________

//>>>>>>> DO HANDS ON ABOVE CODE!!! MOMENT DONE RAISE YOUR HAND

//______________________________________________________________
//______________________________________________________________

// Ownership Rules. 
//  1. Each value in Rust has An OWNER
//  2. There can ONLY be ONE OWNER at a time.
//  3. When the owner goes out of scope, the value will be dropped
//			Because Owner Dies Hence Value/Object It Points To Die

// NOTE NOTE::
// 		GENERALLY PROGRAMERS SOLVE LIFE TIME AS A DESIGN:
// 			We need to pair exactly one allocate with exactly one free

// BUT RUST::
//		SOLVES OWNERSHIP FIRST
// 		Rust takes a different path: the memory is automatically 
// 		returned once the variable that owns it goes out of scope. 

// DESIGN PRINCIPLES
//		1. Design Towards Ownership First
//		2. Than Design/Decide Scope
//		3. Life Time Design
//		4. Visibility : Need To Know Basis

//______________________________________________________________

// Here are some of the types that implement Copy:

// All the integer types, such as u32.
// The Boolean type, bool, with values true and false.
// All the floating point types, such as f64.
// The character type, char.
// Tuples, if they only contain types that also implement Copy. 
// 		For example, (i32, i32) implements Copy, 
// 		but (i32, String) does not.

//______________________________________________________________

fn play_with_greeting( some_string : String ) {
	println!("String Value: {some_string}");
}

fn play_with_number( some_number: i32 ) {
	println!("Number Value: {some_number}");	
}

fn play_with_greeting_again( some_string : &str ) {
	println!("String Value: {some_string}");
}

fn play_with_function_arguments() {

	let greeting = String::from("Good Evening!!!");
	let number = 9090;
	// Move Semantics
	//		Ownership Of String Type Object Shifted From greeting To Function Argument
	//			i.e. some_string Is Owner Of String Type Object Now
	play_with_greeting( greeting );

	// println!("String Value: {greeting}"); // Compilation Error: greeting Doesn't Exists

	//	 Copy Semantics 
	play_with_number( number );
	println!("Number Value: {number}");	

	//	 Copy Semantics 
	let greeting_again = "Good Evening!!!";
	play_with_greeting_again( greeting_again );
	println!("String Value: {greeting_again}");
}

//______________________________________________________________


//>>>>>>> DO HANDS ON ABOVE CODE!!! MOMENT DONE RAISE YOUR HAND

//______________________________________________________________


fn play_with_greeting_once_again( some_string : String ) -> String {
	// Function Argument some_string Took Ownership Of String Type Object
	//			From Caller

	// Some Processing... Custome Code...
	println!("String Value: {some_string}");

	// Returing Value As Well As Shifting Ownership To Caller
	// return some_string;
	some_string 	// Equivalent To return some_string;
}

fn say_greeting( ) -> String {
// fn say_greeting() -> () {
// fn say_greeting() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Reference Is Local To Function
	//		greeting Is Ownership Of "Guten Tag" Object Of String Type
	let greeting = String::from("Guten Tag!!!");

	println!("String Value: {greeting}");
	// BY DEFAULT 
	// 		On Exit From Local Scope Of Function/Local Context
	//				Life Time Of Owner is Over i.e. greeting Is Over
	//			 	"Guten Tag" Object Of String Type Is Dropped

	// Returing The Reference As Well As Shifting Ownership To Caller
	greeting 	// Equivalent To return some_string;
}

fn play_with_function_arguments_again() {
	// greeting Reference Has Ownership of "Good Evening!!!" String Type Object
	let greeting = String::from("Good Evening!!!");

	// Rustian Style
	//			Passing greeting Argument To Function
	//					You Are Shifting The Ownership To Function
	//			Function Is Returning String Type Value
	//					You Are Storing Returned Value In greeting
	//					Shifting The Ownership

	let greeting = play_with_greeting_once_again( greeting );
	println!("String Value: {greeting}");

	// let _ = play_with_greeting_once_again( greeting );
	
	let greeting1 = play_with_greeting_once_again( greeting );	
	// println!("String Value: {greeting}");
	// 				^^^^^^^^^^ value borrowed here after move
	println!("String Value: {greeting1}");

	let got_greeting = say_greeting();
	println!("Greeting: {:?}", got_greeting);
}


//______________________________________________________________

fn calculate_length( some_string : &String ) -> usize {
	some_string.len()
	//  Returns the length of this String, in bytes, 
	//	not chars or graphemes. In other words, it might 
	//	not be what a human considers the length of the string

	// Reference Link:
	//		https://doc.rust-lang.org/std/string/struct.String.html#method.len
}

fn play_with_passing_refrences() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Is Have Ownership Of "Guten Tag" Object Of String Type

	let greeting = String::from("Good Evening!!!");

	// Borrow Semantics 
	// Passing Reference Of greeting
	// Passing Reference Of The Object Whose Ownership Lies With Someone Else
	//							greeting Have Ownership
	// 							Ownership Is Not Shifted
	//					Passing Reference Only But Not Shifting Ownership
	//					&greeting Reference Is A Safe Pointer

	let length = calculate_length( &greeting );
	println!("String Length: {length}");
	println!("String Value : {greeting}");
}

//______________________________________________________________

 // Instead, we can provide a Rust reference to the String value. 
 //     A Rust reference is like a pointer in that it’s an address 
 //		we can follow to access the data stored at that address; 

 //     that data is owned by some other variable. 
 
 //    	UNLIKE a Pointer, a referenc is guaranteed to point 
 //     to a valid value of a particular type for the life of 
 //     that reference.

//______________________________________________________________

// When functions have references as parameters instead 
//      of the actual values, we won’t need to return 
//      the values in order to give back ownership, 
//      because we never had ownership.

// We call the action of creating a reference borrowing. As in real life

//______________________________________________________________

// By Default
//		Function Arguments Are IMMUTABLE By Default

fn change_function( mut some_string: &str ) {
	//  some_string = "Hello!!!" // Here some_string Got It's Own Copy Of "Hello" 
// warning: value passed to `some_string` is never read
//		Explains That Arguments To Functions Should Be Used
//		Rather Create Better API Without Unused Arguments
	println!("Value Inside: {some_string}");	

	some_string = "How Are You Doing?";
	//		Above Changes Are Happening Local To This Function
	//			Local Value Of "Hello!!!" Replaced With "How Are You Doing?"	
	// error[E0384]: cannot assign to immutable argument `some_string`
	println!("Value Inside: {some_string}");	
	// some_string Has Ownership 
}

fn play_with_change_data() {
	//	IMMUTABLE By Default
	// warning: variable does not need to be mutable
	// let mut hello = "Hello!!!";
	let hello = "Hello!!!";

	println!("Value Outside: {hello}");
	//		Copy Semantic
	// 			Hence Passed By Value Immergent Behavior Out Of Copy Semantic
	change_function( hello );
	println!("Value Outside: {hello}");
}

// Function : play_with_change_data
// Value Outside: Hello!!!
// Value Inside: Hello!!!
// Value Inside: How Are You Doing?
// Value Outside: Hello!!!


//______________________________________________________________

fn change_function_again( mut some_string: String ) -> String { // Thead 01
	println!("Value Inside: {some_string}");	

	// Creating Changes/Side Effects
	some_string.push_str(" Mohammed! ");
	println!("Value Inside: {some_string}");
	some_string // Rustian Style Pattern
}

fn play_with_change_function_again() {
	let hello = String::from("Hello");	

	println!("Value Outside: {hello}");	
	//					   Move Semantics
	let hello = change_function_again( hello );
	println!("Value Outside: {hello}");
}

// Function : play_with_change_function_again
// Value Outside: Hello
// Value Inside: Hello
// Value Inside: Hello Mohammed! 

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fn main() {
	println!("\n\n\nFunction : play_with_scope");
	play_with_scope();

	println!("\n\n\nFunction : play_with_scope_again");
	play_with_scope_again();

	println!("\n\n\nFunction : play_with_function_arguments");
	play_with_function_arguments();

	println!("\n\n\nFunction : play_with_function_arguments_again");
	play_with_function_arguments_again();

	println!("\n\n\nFunction : play_with_passing_refrences");
	play_with_passing_refrences();

	println!("\n\n\nFunction : play_with_change_data");
	play_with_change_data();

	println!("\n\n\nFunction : play_with_change_function_again");
	play_with_change_function_again();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

