

fn play_with_scope_again_again(){
    let greeting=String::from("Good Morning");
    println!("Hey:{greeting} {:p}",&greeting);

    let hello=greeting;
    println!("Hey:{hello} {:p}",&hello);

    let greeting="Good Evening";
    println!("Hey:{greeting} {:p}",&greeting);

    let hello=greeting;
    println!("Hey:{hello} {:p}",&hello);
    println!("Hey:{greeting} {:p}",&greeting);
}

fn play_with_greeting_once_again( some_string : &str ) -> &str {
    println!("String Value: {some_string}");
    // Returing Value As Well As Shifting Ownership To Caller
    some_string
}
  
fn play_with_function_arguments_again() {
    let mut greeting = "Good Evening!!!";
    
                                                // Copy Scemantic 
    let greeting1 = play_with_greeting_once_again( greeting );  
    println!("String Value: {greeting1}");
    greeting = "Hello Mo";
    println!("New Mo String Value: {greeting}");
}


