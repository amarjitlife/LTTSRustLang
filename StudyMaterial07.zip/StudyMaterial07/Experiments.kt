
fun playWithIfElse() {
	let condition = true
	
	let number = if (condition) 10 else 20
	println("Value: $number")

	let number = if (condition) {
		10 + 90
		100 + 200  
	} else { 
		20 + 40
		111 + 222
	}
	
	println("Value: $number")

}


fun main() {
	println("\nFunction : playWithIfElse")
	playWithIfElse()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

