
//_____________________________________________________________

// Primitives
// Rust provides access to a wide variety of primitives. A sample includes:

// Scalar Types
// Signed integers: i8, i16, i32, i64, i128 and isize (pointer size)
// Unsigned integers: u8, u16, u32, u64, u128 and usize (pointer size)

// Floating point: f32, f64

// char Unicode scalar values like 'a', 'α' and '∞' (4 bytes each)
// bool either true or false

// The unit type (), whose only possible value is an empty tuple: ()
// 		Despite the value of a unit type being a tuple, 
// 		it is not considered a compound type because it does not contain multiple values.

// Compound Types
// Arrays like [1, 2, 3]
// Tuples like (1, true)

// Variables can always be type annotated. 
// Numbers may additionally be annotated via a suffix or by default. 
// Integers default to i32 and floats to f64. Note that Rust can also infer types from context.

#[allow(unused)]
fn play_with_types() {
    // Variables can be type annotated.
    let logical: bool = true;

    let a_float: f64 = 1.0;   // Regular annotation
    let an_integer   = 5i32;  // Suffix annotation
    let an_integer_again: i32   = 5;  // Suffix annotation

    // Or a default will be used.
    let default_float   = 3.0; // `f64`
    let default_integer = 7;   // `i32`

    // A type can also be inferred from context.
    let mut inferred_type = 12; // Type i64 is inferred from another line.    
    // Bring Safety In Code Rust Compiler Does Usage Analysis
    inferred_type = 4294967296i64;

    // inferred_type = 4294967296;
    // error: literal out of range for `i32`
    println!("inferred_type Value: {inferred_type} ");

    // A mutable variable's value can be changed.
    let mut mutable = 12; // Mutable `i32`
    mutable = 21;

    // Error! The type of a variable can't be changed.
    // mutable = true;

    // Variables can be overwritten with shadowing.
    let mutable = true;

    /* Compound types - Array and Tuple */

    // Array signature consists of Type T and length as [T; length].
    let my_array: [i32; 5] = [1, 2, 3, 4, 5];

    // Tuple is a collection of values of different types 
    // and is constructed using parentheses ().
    let my_tuple = (5u32, 1u8, true, -5.04f32);

	// 	RHS Inferred Type Is i32, 
	//	LHS Annotated Type Is i64
	//		As LHS Type Is Annotated By Programmer As i64 Compiler Will Be i64 With green
	//		And Type Cast Value 4 To i64 At Initialisation Time
    let mut green:i64 = 4 ; 
    println!("green Value: {}",green );

    // Type Of green Is i64
    // green = 9_223_372_036_854_775_900
	// ERROR: the literal `9_223_372_036_854_775_900` does not fit into the type  `i64` 
	//		whose range is `-9223372036854775808..=9223372036854775807`
}

// Function : play_with_types
// inferred_type Value: 4294967296

//_____________________________________________________________

// ASSUMPTIONS!
// a, b data is coming some other function
//      Function Already Validating a and b Values In Wise
//      I have a reason that Summation also not go beyond

fn play_with_overflow_underflow() {
    // let a: i8 = 128;
    let a: i8 = 127;
    let b: i8 = 10;

    // IN RUST:: Following Overflow/Underflow Checks Generated In Debug Mode
    // IN RUST:: Following Overflow/Underflow Checks WILL BE PART OF Release Mode

    // if (a > 0 && b > INT_MAX - a) {
    //     printf("Overflow Happening");
    //     return
    // } else if (a < 0 && b < INT_MIN - a) {
    //     printf("Overflow Happening");
    //     return 
    // }

    let c = a + b;
// ^^^^^ attempt to compute `i8::MAX + 10_i8`, which would overflow
    println!("Result : {c}");
}

// Compile Time Error: literal out of range for `i8`
//   --> RustConceptsMore.rs:88:17
//    |
// 88 |     let a: i8 = 127;
//    |                 ^^^
//    |
//    = note: the literal `128` does not fit into the type `i8` whose range is `-128..=127`
//    = help: consider using the type `u8` instead
//    = note: `#[deny(overflowing_literals)]` on by default

//_____________________________________________________________

// DESIGN CHOICE  :: OVERLOW AND UNDERFLOW

// DESIGN 01. Let Programmer Handle It: C/C++
//         int, char Type :: Finite Range 

//         DESIGNED FOR PERFORMANCE
//                 DESIGN PRINCIPLE: YOU SHOULD NOT PAY FOR IT IF YOU ARE NOT USING IT!!!

// DESIGN 02. Let Defintion Of Type Is Like Mathematics Infinite
//         Data Structure :: 
//         Write A Code In C To Calculate Factorial 3 Digit Number
//         Python
//             Convenience Programmer's 

// DESIGN 03. Let's Compiler Generate Code To Detect Overlow/Underflow
//         Swift Language         
//         Time Complexity Increase


// integer overflow
// will occur, which can result in one of two behaviors. When you’re compiling in debug
// mode, Rust includes checks for integer overflow that cause your program to panic at
// runtime if this behavior occurs. Rust uses the term panicking when a program exits

// When you’re compiling in release mode with the --release flag, 
//      Rust does not include checks for integer overflow that cause panics. 
//      Instead, if overflow occurs, Rust performs two’s complement wrapping.

// To explicitly handle the possibility of overflow, 
//  you can use these families of methods
//      provided by the standard library for primitive numeric types:

// Relying on integer overflow’s wrapping behavior is considered an error.

//      Wrap in all modes with the wrapping_* methods, such as wrapping_add
//      Return the None value if there is overflow with the checked_* methods
//      Return the value and a boolean indicating 
            whether there was overflow with the overflowing_* methods
//      Saturate at the value’s minimum or maximum values with saturating_* methods

//_____________________________________________________________

// What Every Computer Scientist Should Know About Floating-Point Arithmetic
// https://www.itu.dk/~sestoft/bachelor/IEEE754_article.pdf

//_____________________________________________________________


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_types");
	play_with_types();

	println!("\n\n\nFunction : play_with_overflow_underflow");
    play_with_overflow_underflow();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

