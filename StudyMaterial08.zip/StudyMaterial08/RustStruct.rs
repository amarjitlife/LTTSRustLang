// #![allow(unused)]

//_____________________________________________________________

// Associate Type
//		Tuple, Structure

// A struct, or structure, is a custom data type that lets you 
// package together and name multiple related values that make up a meaningful group

// Structure Members Are Called fields, attribute

// Structure and Tuple in that both hold multiple related values. 
// Like tuples, the pieces of a struct can be different types. 
// Unlike with tuples, in a struct you’ll name each piece of data 
// so it’s clear what the values mean.

// Field Syntax field_name : Field Type 

// struct User {
// 		active: bool,
// 		username: String,
// 		email: String,
// 		sign_in_count: u64,
// }


//_____________________________________________________________

struct User {
	active: bool,
	username: String,
	email: String,
	sign_in_count: u64,
}

fn play_with_user() {

	// Instance Creation of Structure User Type
	let user = User {
		active: true,
		username: 	String::from("Rock Star"),
		email: 		String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user.active, user.username, 
		user.email, user.sign_in_count );	

//	user.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign


// Note that the entire instance must be mutable or immutable; 
// Rust doesn’t allow us to mark only certain fields as mutable.


	let mut user1 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	user1.email = "rockstar@yahoo.com".to_string();			
	// let mut user1.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign

	// let someting.some = "Ting Tong";

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	// Can Change Member Orders While Creating Variable Of Type Struct e.g. User Struct
	let user2 = User {
		username: String::from("Rock Star"),
		active: true,
		sign_in_count: 1,
		email: String::from("rockstar@gmail.com"),
	};

	println!("Data : {} {} {} {}", user2.active, user2.username, 
		user2.email, user2.sign_in_count );	

	// let user3 = User {
	// 	active : true, // error: expected `:`, found `=`
	// 	username: "Rock Star",
   // |                   ^^^^^^^^^^^- help: try using a conversion method: `.to_string()`
   // |                   |
   // |                   expected `String`, found `&str`
	// 	email: 	  "rockstar@gmail.com",
	// 	sign_in_count: 1,
	// };


// Creating Instances From Other Instances With Struct Update Syntax
// It’s often useful to create a new instance of a struct that 
// includes most of the values from another instance, but changes some. 
// You can do this using struct update syntax.

	let user4 = User {
		active: false,
		username: user1.username,
		email: user1.email,
		sign_in_count: user1.sign_in_count,
	};

	println!("Data : {} {} {} {}", user4.active, user4.username, 
		user4.email, user4.sign_in_count );	


// The syntax .. specifies that the remaining fields not explicitly set 
// should have the same value as the fields in the given instance.

	let user5 = User {
		active: false,
		..user2 // Assigns user2 member values to user5 remaining members 
	};

	println!("Data : {} {} {} {}", user5.active, user5.username, 
		user5.email, user5.sign_in_count );	


	let user3 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	let user6 = user3;
	println!("Data : {} {} {} {}", user6.active, user6.username, 
		user6.email, user6.sign_in_count );	

	let mut user7 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user7.active = false;
	println!("Data : {} {} {} {}", user7.active, user7.username, 
		user7.email, user7.sign_in_count );		

	let user8: User;

	user8 = user7;
	println!("Data : {} {} {} {}", user8.active, user8.username, 
		user8.email, user8.sign_in_count );		

	let mut user9 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user9.active = false;
	println!("Data : {} {} {} {}", user9.active, user9.username, 
		user9.email, user9.sign_in_count );		

// IMPORTANT NOTE 
// 	Note that the struct update syntax uses = like an assignment; 
//		this is because it moves the data,

}

//_____________________________________________________________


fn build_user( email: String, username: String ) -> User {

// As with any expression, we can construct a new instance of the struct as
// the last expression in the function body to implicitly return that new instance.

	User {
		active: true,
		username: username,
		email: email,
		sign_in_count: 1,
	} // Expression Implicilty Returning User Type Instance
}

fn build_user_better( email: String, username: String ) -> User {

//Because the parameter names and the struct field names 
//	are exactly the same
//  we can use the field init shorthand syntax

	User {
		active: true,
		// Short Cut Notion When Variable Names Are Same As Member Names
		username,
		email,
		sign_in_count: 1,
	}
}

fn play_with_build_user() {
	let mansa = build_user( String::from("mansa@gmail.com"), String::from("Mansa Tell"));

	println!("Data : {} {} {} {}", mansa.active, mansa.username, 
		mansa.email, mansa.sign_in_count );		

	let mansa1 = build_user_better( String::from("mansa@gmail.com"), String::from("Mansa Tellis"));

	println!("Data : {} {} {} {}", mansa1.active, mansa1.username, 
		mansa1.email, mansa1.sign_in_count );		
}


//_____________________________________________________________

// Creating Rectangle Type Using Structure Construct
struct Rectangle {
	width: u32,
	height: u32,
	// center: (u32, u32),
}

// Design Choice 01
fn area( width: u32, height: u32 ) -> u32 {
	width * height
}

// TODO: DISCUSS LATER
// fn area_again( width: u32, height: u32 ) -> u8 {
// 		width * height
// }

// Design Choice 02
// fn area( dimension: (u32, u32) ) -> u32 {
// 	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ `area` redefined here
// 	dimension.0 * dimension.1
// }

// Design Choice 02
fn area_better( dimension: ( u32, u32 ) ) -> u32 {
	dimension.0 * dimension.1
}

// Design Choice 03
fn area_best( rectangle: Rectangle ) -> u32 {
	rectangle.width * rectangle.height
}

fn play_with_area() {
	let width1 = 30;
	let height1 = 50;

	let result = area( width1, height1 );
	println!("Rectangle Area: {}", result );

	let rectangle_dimension = ( width1, height1 ); 
	let result = area_better( rectangle_dimension );
	println!("Rectangle Area: {}", result );

	let rectangle = Rectangle {
		width: 30,
		height: 50,
	};

	let _rectangle1: Rectangle;
	// Lot of Code///

	_rectangle1 = Rectangle {
		width: 30,
		height: 50,
		 // ^^^^^^^^^ missing `height`
		 // height,
	};

	let result = area_best( rectangle );
	println!("Rectangle Area: {}", result );
}

// In Language Desing
// INITIALIZATION DESIGN CHOICES
//		INITIAL VALUE DESIGN

// Design Choice 01
//		e.g. C/C++
//		DESIGN PRINCIPLE
//			You Should Not Pay For It! If You Are Not Using It!

//		No Initial Value Is Defined
//			i.e. It will pick automatically what memory footprint
//			Garbage Initialisation
//		BEST PRACTICE:
//		Hence It's Always Programmer's Responsibility To Initialise To Legal Value

// char ch ;
// 				8 Bit Memory [00011000]
// 		Assume Lanuage Is Designed Default Value of 0 Initialised To 0
// 				8 Bit Memory [00000000]
// 				You Have To Incure Cost Of Write 00000000

// char ch = 'A';
// 				8 Bit Memory [00000000]
// 				You Have To Incure Cost Of Write Binary Value of ASCII 'A'

// Design Choice 02
//		e.g. Java/Python/Go
//		DESIGN PRINCPLE: INITIALISATION SAFE
//			DESIGNED FOR PROGRAMMER CONVENIENCE
//		Default Initial Value Is Defined For Variable Of Type
//			For int Type Default Is 0
//			For boot Type Default Is false
//			For string Type Default Is "" and so on...

// Design Choice 03
//		e.g. Rust Language
//		DESIGN PRINCIPLE
//			You Should Not Pay For It! If You Are Not Using It!

//		Initialisation Happens Only Once and Done By Programmer
//		If Initialisation Is Not Done Before Usage: It's Compilation Error


// TODO: DISCUSS LATER
//		PEFORMANCE w.r.t Rust, C, C++ Classes/Structure
//		MEMORY
//			STRUCTURE LAYOUT AND PADDING

//_____________________________________________________________

// Using Tuple Structs without Named Fields to Create Different Types

// Rust also supports structs that look similar to tuples, called tuple structs. 
// Tuple structs have the added meaning the struct name provides 
// but don’t have names associated with their fields; rather, 
// they just have the types of the fields

// TUPLE STRUCTS
// Custom Tuple Type Using Structure
//		Named Tuple Type
struct Color(u8, u8, u8);

// Creating Custome Tuple Types
//		Point and Point3D Are Two DIFFERENT Types
struct Point( i32, i32, i32 ); 		// 3-Dimensional Point
struct Point3D( i32, i32, i32 ); 	// 3-Dimensional Point

// Structures With Member Field
struct ColorAgain {
	red: u8, 
	green: u8, 
	blue: u8,
}

struct PointAgain {
	x: i32, 
	y: i32, 
	z: i32,
} // 3-Dimentional Point

fn play_with_custom_tuple_types() {
	// Creating white Variable Of Tuple Type: (u8, u8, u8)
	let white: (u8, u8, u8) = (255, 255, 255);
	println!("Color Components RGB: {} {} {}", white.0, white.1, white.2 );

	let black 	= Color( 0, 0, 0 );
	let origin 	= Point( 0, 0, 0 );

	// let black1: (u8, u8, u8) = Color( 0, 0, 0 );
	// // ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	// let origin1: (i32, i32, i32) = Point(0, 0, 0 );
	//  // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	let black2: Color = Color( 0, 0, 0 );
	// ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	let origin2: Point = Point(0, 0, 0 );
	 // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	println!("Color Components RGB: {} {} {}", black.0, black.1, black.2 );
	println!("Coordinates x, y, z : {} {} {}", origin.0, origin.1, origin.2 );

	// println!("Color Components RGB: {} {} {}", black1.0, black1.1, black1.2 );
	// println!("Coordinates x, y, z : {} {} {}", origin1.0, origin1.1, origin1.2 );

	println!("Color Components RGB: {} {} {}", black2.0, black2.1, black2.2 );
	println!("Coordinates x, y, z : {} {} {}", origin2.0, origin2.1, origin2.2 );

	let mut point1: Point = Point( 10, 10, 10 );
	// point1 = Point3D( 20, 20, 30 );
	// ^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `Point3D`
	// Because Created 
	println!("Coordinates x, y, z : {} {} {}", point1.0, point1.1, point1.2 );

	// point1 = PointAgain{ x: 30, y: 40, z: 30, };
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `PointAgain`
}

// RUST IS STRICTLY TYPED LANGUAGE

//_____________________________________________________________

// Unit-Like Structs Without Any Fields
//	You can also define structs that don’t have any fields! 
//	These are called unit-like structs because they behave similarly to ()
//	
// Unit-like structs can be useful when you need to implement a trait 
// on some type but don’t have any data that you want to store in the type itself


// Used To Create A Type
struct AlwaysEqual;

fn play_with_struct_without_fields() {
	let subject: AlwaysEqual = AlwaysEqual ;

	println!("AlwaysEqual Value: {}", subject );
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_user");
	play_with_user();

	println!("\n\n\nFunction : play_with_build_user");
	play_with_build_user();

	println!("\n\n\nFunction : play_with_area");
	play_with_area();

	println!("\n\n\nFunction : play_with_custom_tuple_types");
	play_with_custom_tuple_types();

	println!("\n\n\nFunction : play_with_struct_without_fields");
	play_with_struct_without_fields();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

