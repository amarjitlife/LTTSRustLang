

//_____________________________________________________________

struct UnPrintable {
	first: i32,
	second: i32,
}

#[derive(Debug)]
struct Printable {
	first: i32,
	second: i32,
}

//_____________________________________________________________

fn play_with_debug_information() {
	let data = UnPrintable {
		first: 30,
		second: 50,
	};

	println!("Values: {} {}", data.first, data.second );

	let data_again = Printable {
		first: 30,
		second: 50,
	};

	println!("Data: {:?}", data_again );
	// println!("Data: {}", data_again );
	println!("Data: {:#?}", data_again ); // Used for Pretty-Printing {:#?}
}


//_____________________________________________________________

// Derive the `fmt::Debug` implementation for `Structure`. `Structure`
// is a structure which contains a single `i32`.
#[derive(Debug)]
struct Structure(i32);

// Put a `Structure` inside of the structure `Deep`. 
// Make it printable also.
#[derive(Debug)]
struct Deep( Structure );

fn play_with_debug_information_again() {
    // Printing with `{:?}` is similar to with `{}`.
    println!("{:?} months in a year.", 12);
    println!("{1:?} {0:?} is the {actor:?} name.",
             "Slater",
             "Christian",
             actor="actor's");

    // `Structure` is printable!
    println!("Now {:?} will print!", Structure(3));

    // The problem with `derive` is there is no control over how
    // the results look. What if I want this to just show a `7`?
    println!("Now {:?} will print!", Deep(Structure(7)));
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_debug_information");
	play_with_debug_information();

	println!("\n\n\nFunction : play_with_debug_information_again");
	play_with_debug_information_again();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

