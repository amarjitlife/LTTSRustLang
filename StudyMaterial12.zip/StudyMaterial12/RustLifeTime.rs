
//______________________________________________________________

// Borrow Checker
//  The Rust compiler has a borrow checker that 
//      compares scopes to determine whether all borrows are valid

//      To Valid Code This Condition Should Meet
//      LifeTime Of r =< LifeTime of x
//          'a =< 'b

/*
fn play_with_lifetime() {
    let r; // LifeTime: 'a

    {
        let x = 50; // LifeTime: 'b
        r = &x;
        // ^^ borrowed value does not live long enough
    } // x Will Die After Scope Ends

    println!("Value r: {r}");
}
*/

//  LifeTime Of r > LifeTime of x
//       'a > 'b

//______________________________________________________________

//      LifeTime Of r =< LifeTime of x
//          'a =< 'b

fn play_with_lifetime() {
    let r; // LifeTime: 'a

    let x = 50; // LifeTime: 'b
    r = &x;

    println!("Value r: {r}");
}

//______________________________________________________________

/*
fn longest( x: &str, y: &str ) -> &str {
	// x And y Are Local References
	//		It's Life Time Is Within Scope
    if x.len( ) > y.len( ) {
        x
    } else {
        y
    }
}
*/

/*
// Compiler Wants Complaining That result Reference Might Not Be Pointing Valid Object
error[E0106]: missing lifetime specifier
  --> RustLifeTime.rs:46:35
   |
46 | fn longest( x: &str, y: &str ) -> &str {
   |                ----     ----      ^ expected named lifetime parameter
   |
   = help: this function's return type contains a borrowed value, 
  		 but the signature does not say whether it is borrowed from `x` or `y`
		help: consider introducing a named lifetime parameter
   |
46 | fn longest<'a>( x: &'a str, y: &'a str ) -> &'a str {
   |           ++++      ++          ++           ++

error: aborting due to 1 previous error
*/

// 46 | fn longest<'a>( x: &'a str, y: &'a str ) -> &'a str {
fn longest_again<'a>( x: &'a str, y: &'a str ) -> &'a str {
    if x.len( ) > y.len( ) {
        x
    } else {
        y
    }
}

// LifeTime Of Return Value >= LifeTime Of Maximum x and y
//		( LifeTime Of x  And LifeTime Of Y )
fn play_with_longest1() {
	let string1 = String::from("Hello!");
	let string2 = String::from("Hii!");

	// result Will Contain Either x Or y : Reference Of Target String
	//	result To Be Valid Reference
	//		It Must Point To Existing Object
	//		Hence x And y Reference Must Be Pointing To Valid Object 
	//			Till result Used
	// let result = longest( string1.as_str(), string2 );

	let result = longest_again( string1.as_str(), string2.as_str() );
	println!("The Longest String Is : {}", result );
}

fn play_with_longest2() {
	let string1 = String::from("Hello!");
	{ 
		let string2 = String::from("Hii!");
		let result = longest_again( string1.as_str(), string2.as_str() );
		println!("The Longest String Is : {}", result );
	}
}

/*
fn play_with_longest3() {
	let string1 = String::from("Hello!");
	let result;
	{ 
		let string2 = String::from("Hii!");
		result = longest_again( string1.as_str(), string2.as_str() );
	}
	println!("The Longest String Is : {}", result );
	// ^^^^^^ borrowed value does not live long enough
}
*/

//______________________________________________________________
/*
fn longest_local( x: &str, y: &str ) -> &str {
	// x And y Are Local References
	// result Is Also Local and It's Owner Of String Type Object At Heap
	//		x, y, result  Life Time Is Within Scope	
	let result = String::from("Allocated Hello!!!");

	result.as_str()
	// Moment result Goes Out Of Scope It Dies
	//		Hence Object Pointed By result Also Dies
}
*/

/*
fn longest_local_again<'a>( x: &'a str, y: &'a str ) -> &'a str {
	// x And y Are Local References
	// result Is Also Local and It's Owner Of String Type Object At Heap
	//		x, y, result  Life Time Is Within Scope	
	let result = String::from("Allocated Hello!!!");

	result.as_str()
	// Moment result Goes Out Of Scope It Dies
	//		Hence Object Pointed By result Also Dies
// ------^^^^^^^^^
//     |     |
//     |     returns a value referencing data owned by the current function
//     |     `result` is borrowed here
}
*/

fn longest_local_again( _x: &str, _y: &str ) -> String {
	// x And y Are Local References
	// result Is Also Local and It's Owner Of String Type Object At Heap
	//		x, y, result  Life Time Is Within Scope	
	let result = String::from("Allocated Hello!!!");
	result
}

// Shifting Ownership
#[allow(dead_code)]
fn longest_local_best_design() -> String {
	// x And y Are Local References
	// result Is Also Local and It's Owner Of String Type Object At Heap
	//		x, y, result  Life Time Is Within Scope	
	let result = String::from("Allocated Hello!!!");
	result
}

// error[E0106]: missing lifetime specifier
//    --> RustLifeTime.rs:125:41
//     |
// 125 | fn longest_local( x: &str, y: &str ) -> &str {
//     |                      ----     ----      ^ expected named lifetime parameter
//     |
//     = help: this function's return type contains a borrowed value, 
//     but the signature does not say whether it is borrowed from `x` or `y`
// help: consider introducing a named lifetime parameter
//     |
// 125 | fn longest_local<'a>( x: &'a str, y: &'a str ) -> &'a str {
//     |                 ++++      ++          ++           ++

fn play_with_longest4() {
	let string1 = String::from("Hello!");
	let string2 = String::from("Hii!");
	
	// let result = longest_local( string1.as_str(), string2.as_str() );
	let result = longest_local_again( string1.as_str(), string2.as_str() );
	println!("The Longest String Is : {}", result );
}

//______________________________________________________________

// Lifetime Annotations in Function Signatures

// To use lifetime annotations in function signatures, 
// we need to declare the generic lifetime parameters 
// inside angle brackets between the function name and the parameter list, 
// just as we did with generic type parameters.

// We want the signature to express the following constraint: 
// the returned reference will be valid as long as both the parameters are valid. 
// This is the relationship between lifetimes of the parameters and the return value.

// we’re specifying that the borrow checker should reject 
// any values that don’t adhere to these constraints.

//______________________________________________________________

// Lifetime Annotations in Struct Definitions

// So far, the structs we’ve defined all hold owned types. 
// We can define structs to hold references, but in that case 
// we would need to add a lifetime annotation on every reference
// in the struct’s definition.

// #[derive(Debug)]
// struct ImportantPart {
//     part: &str,
// }

#[derive(Debug)]
struct ImportantPart<'a> {
    part: &'a str,
}

#[allow(dead_code)]
impl<'a> ImportantPart<'a> {
	fn announce_and_return_part(&self, announcement: &str) -> &str {
		println!("Attention please: {}", announcement);
		self.part
	}
}

fn play_with_important_part() {
    let novel = String::from("Call me Ishmael. Some years ago...");
    let first_sentence: &str = novel.split('.').next().expect("Could not find a '.'");
    
    let important = ImportantPart {
        part: first_sentence,
    };

    println!("Value : {:?}", important );
    println!("Value : {}", important.part );
}

//______________________________________________________________
//______________________________________________________________

// Lifetime Elision

// You’ve learned that every reference has a lifetime and 
// that you need to specify lifetime parameters for functions 
// or structs that use references

// fn first_word_best<'a>( s: &'a str ) -> &'a str {
fn first_word_best( s: &str ) -> &str {
	let bytes = s.as_bytes();
	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}
	&s[..]
}

// Compiler Will Generate Following Defintion
// 	borrow checker could infer the lifetimes in these
//		situations and wouldn’t need explicit annotations.
// fn first_word_best<'a>( s: &'a str ) -> &'a str {
// }

// Lifetimes on function or method parameters are called input lifetimes, 
// and lifetimes on return values are called output lifetimes.

// The compiler uses three rules to figure out the lifetimes of 
// the references when there aren’t explicit annotations

// These rules apply to fn definitions as well as impl blocks.

// 1. The first rule is that the compiler assigns a lifetime parameter 
// 		to each parameter that’s a reference

		// fn foo (x: &i32 )
		// fn foo<'a> (x: &'a i32 )

	// In other words, a function with one parameter gets one lifetime parameter: 
		// fn foo<'a>(x: &'a i32) ; 

	// a function with two parameters gets two separate lifetime parameters: 
	//		fn foo<'a, 'b>(x: &'a i32, y: &'b i32) ; and so on.

// 2. The second rule is that, if there is exactly one input lifetime parameter, 
//		that lifetime is assigned to all output lifetime parameters: 

//		fn foo<'a>(x: &'a i32) -> &'a i32 .

// 3. The third rule is that, if there are multiple input lifetime parameters, 
//	but one of them is &self or &mut self because this is a method, 
//	the lifetime of self is assigned to all output lifetime parameters


// fn longest<'a, 'b> ( x: &'a str, y: &'b str ) -> &str { // Compiler Will Give Error

fn play_with_first_word_best() {
	let sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word_best( &sentence );
	println!("Result : {word}");
}

//______________________________________________________________

fn play_with_static_lifetime() {
	let s: &str = "I have a Local lifetime.";
	let ss: &'static str = "I have a Static lifetime.";	

	println!("{}", s);
	println!("{}", ss);
}

fn play_with_static_data() {
	static FOO: [i32; 5] = [1, 2, 3, 4, 5];
	static SOME: i32 = 99;

	let r1 = &FOO as *const _;
	let r2 = &FOO as *const _;
	// With a strictly read-only static, references will have the same address
	assert_eq!(r1, r2);
	// A static item can be used just like a variable in many cases
	println!("{FOO:?}");
	println!("{SOME}");
}

//______________________________________________________________

use std::fmt::Display;

fn longest_with_an_announcement<'a, T>(
	x: &'a str,
	y: &'a str,
	ann: T, ) -> &'a str
where
	T: Display,
{
	println!("Announcement! {}", ann);
	if x.len() > y.len() {
		x
	} else {
		y
	}
}

fn play_with_longest_with_announcement() {
	let announcement = "Hello World!!!";
	let string1 = "Donald Trump";
	let string2 = "Aymen";

	let result = longest_with_an_announcement(string1, string2, announcement);
	println!("Result : {result}");
}


//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_lifetime");
    play_with_lifetime();

    println!("\n\n\nFunction : play_with_longest");
    play_with_longest1();

    println!("\n\n\nFunction : play_with_longest2");
    play_with_longest2();

	println!("\n\n\nFunction : play_with_longest4");
	play_with_longest4();

	println!("\n\n\nFunction : play_with_important_part");
	play_with_important_part();

	println!("\n\n\nFunction : play_with_first_word_best");
	play_with_first_word_best();

	println!("\n\n\nFunction : play_with_static_lifetime");
	play_with_static_lifetime();

	println!("\n\n\nFunction : play_with_longest_with_announcement");
	play_with_longest_with_announcement();

	println!("\n\n\nFunction : play_with_static_data");
	play_with_static_data();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

