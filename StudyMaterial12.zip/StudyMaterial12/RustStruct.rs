// #![allow(unused)]

//_____________________________________________________________

// Associate Type
//		Tuple, Structure

// A struct, or structure, is a custom data type that lets you 
// package together and name multiple related values that make up a meaningful group

// Structure Members Are Called fields, attribute

// Structure and Tuple in that both hold multiple related values. 
// Like tuples, the pieces of a struct can be different types. 
// Unlike with tuples, in a struct you’ll name each piece of data 
// so it’s clear what the values mean.

// Field Syntax field_name : Field Type 

// struct User {
// 		active: bool,
// 		username: String,
// 		email: String,
// 		sign_in_count: u64,
// }


//_____________________________________________________________

struct User {
	active: bool,
	username: String,
	email: String,
	sign_in_count: u64,
}

fn play_with_user() {

	// Instance Creation of Structure User Type
	let user = User {
		active: true,
		username: 	String::from("Rock Star"),
		email: 		String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user.active, user.username, 
		user.email, user.sign_in_count );	

//	user.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign


// Note that the entire instance must be mutable or immutable; 
// Rust doesn’t allow us to mark only certain fields as mutable.


	let mut user1 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	user1.email = "rockstar@yahoo.com".to_string();			
	// let mut user1.email = "rockstar@yahoo.com".to_string();	// Error: ^^^^^^^^^^ cannot assign

	// let someting.some = "Ting Tong";

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	// Can Change Member Orders While Creating Variable Of Type Struct e.g. User Struct
	let user2 = User {
		username: String::from("Rock Star"),
		active: true,
		sign_in_count: 1,
		email: String::from("rockstar@gmail.com"),
	};

	println!("Data : {} {} {} {}", user2.active, user2.username, 
		user2.email, user2.sign_in_count );	

	// let user3 = User {
	// 	active : true, // error: expected `:`, found `=`
	// 	username: "Rock Star",
   // |                   ^^^^^^^^^^^- help: try using a conversion method: `.to_string()`
   // |                   |
   // |                   expected `String`, found `&str`
	// 	email: 	  "rockstar@gmail.com",
	// 	sign_in_count: 1,
	// };


// Creating Instances From Other Instances With Struct Update Syntax
// It’s often useful to create a new instance of a struct that 
// includes most of the values from another instance, but changes some. 
// You can do this using struct update syntax.

	let user4 = User {
		active: false,
		username: user1.username,
		email: user1.email,
		sign_in_count: user1.sign_in_count,
	};

	println!("Data : {} {} {} {}", user4.active, user4.username, 
		user4.email, user4.sign_in_count );	


// The syntax .. specifies that the remaining fields not explicitly set 
// should have the same value as the fields in the given instance.

	let user5 = User {
		active: false,
		..user2 // Assigns user2 member values to user5 remaining members 
	};

	println!("Data : {} {} {} {}", user5.active, user5.username, 
		user5.email, user5.sign_in_count );	


	let user3 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	let user6 = user3;
	println!("Data : {} {} {} {}", user6.active, user6.username, 
		user6.email, user6.sign_in_count );	

	let mut user7 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user7.active = false;
	println!("Data : {} {} {} {}", user7.active, user7.username, 
		user7.email, user7.sign_in_count );		

	let user8: User;

	user8 = user7;
	println!("Data : {} {} {} {}", user8.active, user8.username, 
		user8.email, user8.sign_in_count );		

	let mut user9 = User {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	user9.active = false;
	println!("Data : {} {} {} {}", user9.active, user9.username, 
		user9.email, user9.sign_in_count );		

// IMPORTANT NOTE 
// 	Note that the struct update syntax uses = like an assignment; 
//		this is because it moves the data,

}

//_____________________________________________________________


fn build_user( email: String, username: String ) -> User {

// As with any expression, we can construct a new instance of the struct as
// the last expression in the function body to implicitly return that new instance.

	User {
		active: true,
		username: username,
		email: email,
		sign_in_count: 1,
	} // Expression Implicilty Returning User Type Instance
}

fn build_user_better( email: String, username: String ) -> User {

//Because the parameter names and the struct field names 
//	are exactly the same
//  we can use the field init shorthand syntax

	User {
		active: true,
		// Short Cut Notion When Variable Names Are Same As Member Names
		username,
		email,
		sign_in_count: 1,
	}
}

fn play_with_build_user() {
	let mansa = build_user( String::from("mansa@gmail.com"), String::from("Mansa Tell"));

	println!("Data : {} {} {} {}", mansa.active, mansa.username, 
		mansa.email, mansa.sign_in_count );		

	let mansa1 = build_user_better( String::from("mansa@gmail.com"), String::from("Mansa Tellis"));

	println!("Data : {} {} {} {}", mansa1.active, mansa1.username, 
		mansa1.email, mansa1.sign_in_count );		
}


//_____________________________________________________________

// Creating Rectangle Type Using Structure Construct
struct Rectangle {
	width: u32,
	height: u32,
	// center: (u32, u32),
}

// Design Choice 01
fn area( width: u32, height: u32 ) -> u32 {
	width * height
}

// TODO: DISCUSS LATER
// fn area_again( width: u32, height: u32 ) -> u8 {
// 		width * height
// }

// Design Choice 02
// fn area( dimension: (u32, u32) ) -> u32 {
// 	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ `area` redefined here
// 	dimension.0 * dimension.1
// }

// Design Choice 02
fn area_better( dimension: ( u32, u32 ) ) -> u32 {
	dimension.0 * dimension.1
}

// Design Choice 03
fn area_best( rectangle: Rectangle ) -> u32 {
	rectangle.width * rectangle.height
}

fn play_with_area() {
	let width1 = 30;
	let height1 = 50;

	let result = area( width1, height1 );
	println!("Rectangle Area: {}", result );

	let rectangle_dimension = ( width1, height1 ); 
	let result = area_better( rectangle_dimension );
	println!("Rectangle Area: {}", result );

	let rectangle = Rectangle {
		width: 30,
		height: 50,
	};

	let _rectangle1: Rectangle;
	// Lot of Code///

	_rectangle1 = Rectangle {
		width: 30,
		height: 50,
		 // ^^^^^^^^^ missing `height`
		 // height,
	};

	let result = area_best( rectangle );
	println!("Rectangle Area: {}", result );
}

// In Language Desing
// INITIALIZATION DESIGN CHOICES
//		INITIAL VALUE DESIGN

// Design Choice 01
//		e.g. C/C++
//		DESIGN PRINCIPLE
//			You Should Not Pay For It! If You Are Not Using It!

//		No Initial Value Is Defined
//			i.e. It will pick automatically what memory footprint
//			Garbage Initialisation
//		BEST PRACTICE:
//		Hence It's Always Programmer's Responsibility To Initialise To Legal Value

// char ch ;
// 				8 Bit Memory [00011000]
// 		Assume Lanuage Is Designed Default Value of 0 Initialised To 0
// 				8 Bit Memory [00000000]
// 				You Have To Incure Cost Of Write 00000000

// char ch = 'A';
// 				8 Bit Memory [00000000]
// 				You Have To Incure Cost Of Write Binary Value of ASCII 'A'

// Design Choice 02
//		e.g. Java/Python/Go
//		DESIGN PRINCPLE: INITIALISATION SAFE
//			DESIGNED FOR PROGRAMMER CONVENIENCE
//		Default Initial Value Is Defined For Variable Of Type
//			For int Type Default Is 0
//			For boot Type Default Is false
//			For string Type Default Is "" and so on...

// Design Choice 03
//		e.g. Rust Language
//		DESIGN PRINCIPLE
//			You Should Not Pay For It! If You Are Not Using It!

//		Initialisation Happens Only Once and Done By Programmer
//		If Initialisation Is Not Done Before Usage: It's Compilation Error


// TODO: DISCUSS LATER
//		PEFORMANCE w.r.t Rust, C, C++ Classes/Structure
//		MEMORY
//			STRUCTURE LAYOUT AND PADDING

//_____________________________________________________________

// Using Tuple Structs without Named Fields to Create Different Types

// Rust also supports structs that look similar to tuples, called tuple structs. 
// Tuple structs have the added meaning the struct name provides 
// but don’t have names associated with their fields; rather, 
// they just have the types of the fields

// TUPLE STRUCTS
// Custom Tuple Type Using Structure
//		Named Tuple Type
struct Color(u8, u8, u8);

// Creating Custome Tuple Types
//		Point and Point3D Are Two DIFFERENT Types
struct Point( i32, i32, i32 ); 		// 3-Dimensional Point

#[allow(dead_code)]
struct Point3D( i32, i32, i32 ); 	// 3-Dimensional Point

// Structures With Member Field
#[allow(dead_code)]
struct ColorAgain {
	red: u8, 
	green: u8, 
	blue: u8,
}

#[allow(dead_code)]
struct PointAgain {
	x: i32, 
	y: i32, 
	z: i32,
} // 3-Dimentional Point

fn play_with_custom_tuple_types() {
	// Creating white Variable Of Tuple Type: (u8, u8, u8)
	let white: (u8, u8, u8) = (255, 255, 255);
	println!("Color Components RGB: {} {} {}", white.0, white.1, white.2 );

	let black 	= Color( 0, 0, 0 );
	let origin 	= Point( 0, 0, 0 );

	// let black1: (u8, u8, u8) = Color( 0, 0, 0 );
	// // ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	// let origin1: (i32, i32, i32) = Point(0, 0, 0 );
	//  // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	let black2: Color = Color( 0, 0, 0 );
	// ^^^^^^^^^^^^^^^^ expected `(u8, u8, u8)`, found `Color`
	let origin2: Point = Point(0, 0, 0 );
	 // ^^^^^^^^^^^^^^^ expected `(i32, i32, i32)`, found `Point`

	println!("Color Components RGB: {} {} {}", black.0, black.1, black.2 );
	println!("Coordinates x, y, z : {} {} {}", origin.0, origin.1, origin.2 );

	// println!("Color Components RGB: {} {} {}", black1.0, black1.1, black1.2 );
	// println!("Coordinates x, y, z : {} {} {}", origin1.0, origin1.1, origin1.2 );

	println!("Color Components RGB: {} {} {}", black2.0, black2.1, black2.2 );
	println!("Coordinates x, y, z : {} {} {}", origin2.0, origin2.1, origin2.2 );

	let point1: Point = Point( 10, 10, 10 );
	// let mut point1: Point = Point( 10, 10, 10 );
	// point1 = Point3D( 20, 20, 30 );
	// ^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `Point3D`
	// Because Created 
	println!("Coordinates x, y, z : {} {} {}", point1.0, point1.1, point1.2 );

	// point1 = PointAgain{ x: 30, y: 40, z: 30, };
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ expected `Point`, found `PointAgain`
}

// RUST IS STRICTLY TYPED LANGUAGE

//_____________________________________________________________

// Unit-Like Structs Without Any Fields
//	You can also define structs that don’t have any fields! 
//	These are called unit-like structs because they behave similarly to ()
//	
// Unit-like structs can be useful when you need to implement a trait 
// on some type but don’t have any data that you want to store in the type itself

// Used To Create A Type
struct AlwaysEqual;

fn play_with_struct_without_fields() {
	let _subject: AlwaysEqual = AlwaysEqual ;

	// println!("AlwaysEqual Value: {}", subject );
	// 		error[E0277]: `AlwaysEqual` doesn't implement `std::fmt::Display`
}

//_____________________________________________________________

// METHODS - MEMBER FUNCTIONS

struct RectangleAgain {
	width: u32,
	height: u32,
}

//	Associative Functions
//		All functions defined within an impl block are called associated functions 
//		because they’re associated with the type named after the impl . 

//		We can define associated functions that don’t have self as their first parameter
//		(and thus are not methods) because they don’t need an instance of the type to work with.

impl RectangleAgain {
	// Associative Function - Method
	// 		Methods - Member Functions Which Takes First Argument self Of Self Type
	//		&Self means We Are Borrowing self
	fn area( self: &Self ) -> u32 {
		self.width * self.height
	}

	// Associative Function - Method
	// 		&self Is A Shortcut Syntax Of First Argument viz. self: &Self 
	fn is_width( &self ) -> bool {
		self.width > 0
	}

	// Associative Function - Method
	// 		&self Is A Shortcut Syntax Of First Argument viz. self: &Self
	// 		Method Taking More Than 1 Arugment
	fn can_hold( &self, other: &RectangleAgain ) -> bool {
		self.width > other.width && self.height > other.height
	}

	// Associative Function
	// 		Associated functions that aren’t methods are often used for 
	//		constructors that will return a new instance of the struct. 
	//		These are often called new , but new isn’t a special name and 
	//		isn’t built into the language

	//		Because It Doesn't Take self As First Argument
	// Factory Function i.e. Function Which Creates Objects
	//		square Function Creating Object Of Self Type i.e. RectangleAgain
	//		Called Using :: Followed By Type Name

	// The Self keywords in the return type and in the body of the function 
	//	are aliases for the type that appears after the impl keyword, 
	//	which in this case is RectangleAgain

	fn square( size: u32 ) -> Self {
		Self {
			width: size,
			height: size
		}
	}
}

fn play_with_rectanlge_again_methods() {
	let rectangle1 = RectangleAgain {
		width: 30,
		height: 50,
	};

	let rectangle2 = RectangleAgain {
		width: 20,
		height: 40,
	};

	// Methods Are Called Using . Operator After Object
	println!("Rectangle Area : {}", rectangle1.area() );
	println!("Rectangle Width: {}", rectangle1.is_width() );	
	println!("Rectangle Can Hold : {}", rectangle1.can_hold( &rectangle2 ) );
}

//_____________________________________________________________

// Methods are similar to functions: we declare them with the fn keyword and a name, they
// can have parameters and a return value, and they contain some code that’s run when the
// method is called from somewhere else. Unlike functions, methods are defined within the
// context of a struct (or an enum or a trait object

// and their first parameter is always self , which represents the instance of the
// struct the method is being called on.

// instead of rectangle: &Rectangle . The &self is actually short for self: &Self . 

// Within an impl block, the type Self is an alias for the type
// that the impl block is for. Methods must have a parameter named 
// self of type Self for their first parameter, so Rust lets you 
// abbreviate this with only the name self in the first parameter spot. 

// Note that we still need to use the & in front of the self shorthand to
// indicate this method borrows the Self instance, 

// Just as we did in rectangle: &Rectangle . Methods can take ownership of self, 
// borrow self immutably as we’ve done here, or borrow self mutably, 
// just as they can any other parameter.

// We’ve chosen &self here for the same reason we used &Rectangle in the function version:
// we don’t want to take ownership, and we just want to read the data in the struct, 
// not write to it. If we wanted to change the instance that we’ve called the method 
// on as part of what the method does, we’d use &mut self as the first parameter.

// Note that we can choose to give a method the same name as one of the struct’s fields.
// 		when we follow rect1.width with parentheses, 
//				Rust knows we mean the method width . 
//		When we don’t use parentheses, 
//				Rust knows we mean the field width .

//_____________________________________________________________

fn play_with_associative_functions() {
	let rectangle1 = RectangleAgain {
		width: 30,
		height: 50,
	};

	let rectangle2 = RectangleAgain {
		width: 20,
		height: 40,
	};

	println!("Rectangle Can Hold : {}", rectangle1.can_hold( &rectangle2 ) );	

	let square = RectangleAgain::square( 22 );
	println!("Square Width: {} Height: {}", square.width, square.height );	
}


//_____________________________________________________________

struct UserAgain {
	active: bool,
	username: String,
	email: String,
	sign_in_count: u64,
}

fn play_with_structure_objects() {
	let user1 = UserAgain {
		active: true,
		username: String::from("Rock Star"),
		email: String::from("rockstar@gmail.com"),
		sign_in_count: 1,
	};

	println!("Data : {} {} {} {}", user1.active, user1.username, 
		user1.email, user1.sign_in_count );	

	let user2 = UserAgain {
		active: false,
		..user1 // Assigns user1 member values to user2 remaining members 
		// error[E0382]: use of moved value: `user1.username`
	};

	println!("Data : {} {} {} {}", user2.active, user2.username, 
		user2.email, user2.sign_in_count );	

	// let user3 = UserAgain {
	// 	active: false,
	// 	..user1 // Assigns user1 member values to user3 remaining members 
    // // | |_____^ value used here after move		
	// };

	// println!("Data : {} {} {} {}", user3.active, user3.username, 
	// 	user3.email, user3.sign_in_count );	
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_user");
	play_with_user();

	println!("\n\n\nFunction : play_with_build_user");
	play_with_build_user();

	println!("\n\n\nFunction : play_with_area");
	play_with_area();

	println!("\n\n\nFunction : play_with_custom_tuple_types");
	play_with_custom_tuple_types();

	println!("\n\n\nFunction : play_with_struct_without_fields");
	play_with_struct_without_fields();

	println!("\n\n\nFunction : play_with_rectanlge_again_methods");
	play_with_rectanlge_again_methods();

	println!("\n\n\nFunction : play_with_associative_functions");
	play_with_associative_functions();

	println!("\n\n\nFunction : play_with_structure_objects");
	play_with_structure_objects();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

