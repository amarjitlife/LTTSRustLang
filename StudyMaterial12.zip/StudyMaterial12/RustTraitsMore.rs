
//______________________________________________________________

trait Animal {
    // Associated function signature; 
    // 		`Self` refers to the implementor type.
    fn new(name: &'static str) -> Self;

    // Method signatures; these will return a string.
    fn name(&self) -> &'static str;
    fn noise(&self) -> &'static str;

    // Traits can provide default method definitions.
    fn talk(&self) {
        println!("Talks {}", self.name());
    }

    // Traits can provide default method definitions.
    fn walk(&self) {
        println!("Walks {} ", self.name());
    }
}

struct Sheep { 
    naked: bool, 
    name: &'static str 
}


impl Sheep {
    fn is_naked(&self) -> bool {
        self.naked
    }

    fn shear(&mut self) {
        if self.is_naked() {
            // Implementor methods can use the implementor's trait methods.
            println!("{} is already naked...", self.name());
        } else {
            println!("{} gets a haircut!", self.name);

            self.naked = true;
        }
    }
}

// Implement the `Animal` trait for `Sheep`.
impl Animal for Sheep {
    // `Self` is the implementor type: `Sheep`.
    fn new(name: &'static str) -> Sheep {
        Sheep { name: name, naked: false }
    }

    fn name(&self) -> &'static str {
        self.name
    }

    fn noise(&self) -> &'static str {
        if self.is_naked() {
            "baaaaah?"
        } else {
            "baaaaah!"
        }
    }
    
    // Default trait methods can be overridden.
    fn talk(&self) {
        // For example, we can add some quiet contemplation.
        println!("{} pauses briefly... {}", self.name, self.noise());
    }
}

fn play_with_traits() {
    // Type annotation is necessary in this case.
    let mut dolly: Sheep = Animal::new("Dolly");
    // TODO ^ Try removing the type annotations.

    dolly.talk();
    dolly.shear();
    dolly.talk();
    dolly.walk();
}

//______________________________________________________________

use std::fmt;

struct Point {
    x: i32,
    y: i32,
}

impl fmt::Debug for Point {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Point")
         .field("x", &self.x)
         .field("y", &self.y)
         .finish()
    }
}

#[allow(dead_code)]
#[derive(Debug)]
struct PointAgain {
    x: i32,
    y: i32,
}


fn play_with_debug_trait() { 
	let origin = Point { x: 0, y: 0 };

	assert_eq!(
	    format!("The origin is: {origin:?}"),
	    "The origin is: Point { x: 0, y: 0 }",
	);

	let origin1 = PointAgain { x: 0, y: 0 };

	assert_eq!(
	    format!("The origin is: {origin1:?}"),
	    "The origin is: PointAgain { x: 0, y: 0 }",
	);
}

//______________________________________________________________
//______________________________________________________________


// `Centimeters`, a tuple struct that can be compared
#[derive(PartialEq, PartialOrd)]
struct Centimeters(f64);

// `Inches`, a tuple struct that can be printed
#[derive(Debug)]
struct Inches(i32);

impl Inches {
    fn to_centimeters(&self) -> Centimeters {
        let &Inches(inches) = self;

        Centimeters(inches as f64 * 2.54)
    }
}

// `Seconds`, a tuple struct with no additional attributes
#[derive(Debug)]
struct Seconds(i32);

fn play_with_derive_traits() {
    let one_second = Seconds(1);

    // Error: `Seconds` can't be printed; it doesn't implement the `Debug` trait
    println!("One second looks like: {:?}", one_second);
    println!("One second looks like: {}", one_second.0);

    // TODO ^ Try uncommenting this line

    // Error: `Seconds` can't be compared; 
    //      it doesn't implement the `PartialEq` trait
    //let _this_is_true = (_one_second == _one_second);
    // TODO ^ Try uncommenting this line

    let foot = Inches(12);

    println!("One foot equals {:?}", foot);

    let meter1 = Centimeters(100.0);
    let meter2 = Centimeters(100.0);
    let meter3 = Centimeters(200.0);
    println!("Results Equals {:?}", meter1 == meter2 );
    println!("Results Equals {:?}", meter1 == meter3 );
    
    let cmp = if foot.to_centimeters() < meter1 {
                    "smaller"
                } else {
                    "bigger"
                };

    println!("One foot is {} than one meter.", cmp);
}

//______________________________________________________________

struct Sheep1 {}
struct Cow1 {}

trait Animal1 {
    // Instance method signature
    fn noise(&self) -> &'static str;
}

// Implement the `Animal` trait for `Sheep`.
impl Animal1 for Sheep1 {
    fn noise(&self) -> &'static str {
        "baaaaah!"
    }
}

// Implement the `Animal` trait for `Cow`.
impl Animal1 for Cow1 {
    fn noise(&self) -> &'static str {
        "moooooo!"
    }
}

// Returns some struct that implements Animal, 
// but we don't know which one at compile time.
fn random_animal(random_number: f64) -> Box<dyn Animal1> {
    if random_number < 0.5 {
        Box::new(Sheep1 {})
    } else {
        Box::new(Cow1 {})
    }
}

fn play_with_trait_with_dyn_return() {
    let random_number = 0.234;
    let animal = random_animal(random_number);
    println!("You've randomly chosen an animal, and it says {}", animal.noise());
}

//______________________________________________________________

enum BookFormat {
    Paperback,
    Hardback,
    Ebook,
}

struct Book {
    isbn: i32,
    format: BookFormat,
}

impl PartialEq for Book {

    fn eq(&self, other: &Self) -> bool {
        self.isbn == other.isbn
    }
}

fn plauy_partial_eq_trait() {
	let b1 = Book { isbn: 3, format: BookFormat::Paperback };
	let b2 = Book { isbn: 3, format: BookFormat::Ebook };
	let b3 = Book { isbn: 10, format: BookFormat::Paperback };

	assert!(b1 == b2);
	assert!(b1 != b3);
}

//______________________________________________________________
//______________________________________________________________

use std::ops::Add;

#[derive(Debug, Copy, Clone, PartialEq)]
struct PointMore {
    x: i32,
    y: i32,
}

impl Add for PointMore {
    type Output = Self;

    fn add(self, other: Self) -> Self {
        Self {
            x: self.x + other.x,
            y: self.y + other.y,
        }
    }
}

fn play_with_operator_overloading() { 
	let point11 = PointMore { x: 1, y: 0 };
	let point22 = PointMore { x: 2, y: 3 };
	let point1 =  point11 + point22; // point11.add( point22 ) 
	let point2 =  point22 + point11; // point22.add( point11 ) 

   	let point3 = PointMore { x: 3, y: 3 };

	println!("Point: {:?}" ,{point1});
	println!("Point: {:?}" ,{point2});
	println!("Point: {:?}" ,{point3});

	let result = point1 == point2;
	println!("Result : {result}");
	let result = point1 == point3;
	println!("Result : {result}");
}

//______________________________________________________________



use std::ops;

struct Foo;
struct Bar;

#[derive(Debug)]
struct FooBar;

#[derive(Debug)]
struct BarFoo;

// The `std::ops::Add` trait is used to specify the functionality of `+`.
// Here, we make `Add<Bar>` - the trait for addition with a RHS of type `Bar`.
// The following block implements the operation: Foo + Bar = FooBar
impl ops::Add<Bar> for Foo {
    type Output = FooBar;

    fn add(self, _rhs: Bar) -> FooBar {
        println!("> Foo.add(Bar) was called");

        FooBar
    }
}

// By reversing the types, we end up implementing non-commutative addition.
// Here, we make `Add<Foo>` - the trait for addition with a RHS of type `Foo`.
// This block implements the operation: Bar + Foo = BarFoo
impl ops::Add<Foo> for Bar {
    type Output = BarFoo;

    fn add(self, _rhs: Foo) -> BarFoo {
        println!("> Bar.add(Foo) was called");

        BarFoo
    }
}

fn play_with_operator_overloading_again() {
    println!("Foo + Bar = {:?}", Foo + Bar);
    println!("Bar + Foo = {:?}", Bar + Foo);
}

//______________________________________________________________

struct Fibonacci {
    curr: u32,
    next: u32,
}

// Implement `Iterator` for `Fibonacci`.
// The `Iterator` trait only requires a method to be defined for the `next` element,
// and an `associated type` to declare the return type of the iterator.
impl Iterator for Fibonacci {
    // We can refer to this type using Self::Item
    type Item = u32;

    // Here, we define the sequence using `.curr` and `.next`.
    // The return type is `Option<T>`:
    //     * When the `Iterator` is finished, `None` is returned.
    //     * Otherwise, the next value is wrapped in `Some` and returned.
    // We use Self::Item in the return type, so we can change
    // the type without having to update the function signatures.

    fn next(&mut self) -> Option<Self::Item> {
        let current = self.curr;

        self.curr = self.next;
        self.next = current + self.next;

        // Since there's no endpoint to a Fibonacci sequence, the `Iterator` 
        // will never return `None`, and `Some` is always returned.
        Some(current)
    }
}

// Returns a Fibonacci sequence generator
fn fibonacci() -> Fibonacci {
    Fibonacci { curr: 0, next: 1 }
}

fn play_with_iterator() {
    // `0..3` is an `Iterator` that generates: 0, 1, and 2.
    let mut sequence = 0..3;

    println!("Four consecutive `next` calls on 0..3");
    println!("> {:?}", sequence.next());
    println!("> {:?}", sequence.next());
    println!("> {:?}", sequence.next());
    println!("> {:?}", sequence.next());

    // `for` works through an `Iterator` until it returns `None`.
    // Each `Some` value is unwrapped and bound to a variable (here, `i`).
    println!("Iterate through 0..3 using `for`");
    for i in 0..3 {
        println!("> {}", i);
    }

    // The `take(n)` method reduces an `Iterator` to its first `n` terms.
    println!("The first four terms of the Fibonacci sequence are: ");
    for i in fibonacci().take(4) {
        println!("> {}", i);
    }

    // The `skip(n)` method shortens an `Iterator` by dropping its first `n` terms.
    println!("The next four terms of the Fibonacci sequence are: ");
    for i in fibonacci().skip(4).take(4) {
        println!("> {}", i);
    }

    let array = [1u32, 3, 3, 7];

    // The `iter` method produces an `Iterator` over an array/slice.
    println!("Iterate the following array {:?}", &array);
    for i in array.iter() {
        println!("> {}", i);
    }
}

//______________________________________________________________

//______________________________________________________________

#[allow(dead_code)]
trait Person {
    fn name(&self) -> String;
}

// Person is a supertrait of Student.
// Implementing Student requires you to also impl Person.
#[allow(dead_code)]
trait Student: Person {
    fn university(&self) -> String;
}

#[allow(dead_code)]
trait Programmer {
    fn fav_language(&self) -> String;
}

// CompSciStudent (computer science student) is a subtrait of both Programmer 
// and Student. Implementing CompSciStudent requires you to impl both supertraits.
#[allow(dead_code)]
trait CompSciStudent: Programmer + Student {
    fn git_username(&self) -> String;
}

#[allow(dead_code)]
fn comp_sci_student_greeting(student: &dyn CompSciStudent) -> String {
    format!(
        "My name is {} and I attend {}. My favorite language is {}. My Git username is {}",
        student.name(),
        student.university(),
        student.fav_language(),
        student.git_username()
    )
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
    println!("\n\n\nFunction : play_with_traits");
    play_with_traits();

    println!("\n\n\nFunction : play_with_debug_trait");
    play_with_debug_trait();

    println!("\n\n\nFunction : play_with_derive_traits");
    play_with_derive_traits();

    println!("\n\n\nFunction : play_with_trait_with_dyn_return");
    play_with_trait_with_dyn_return();


    println!("\n\n\nFunction : play_with_iterator");
    play_with_iterator();

    // println!("\n\n\nFunction : comp_sci_student_greeting");
    // comp_sci_student_greeting();

    println!("\n\n\nFunction : plauy_partial_eq_trait");
    plauy_partial_eq_trait();
    
    println!("\n\n\nFunction : play_with_operator_overloading");
    play_with_operator_overloading();

    println!("\n\n\nFunction : play_with_operator_overloading_again");
    play_with_operator_overloading_again();

    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
}

