
#include <stdio.h>

//________________________________________________________

void play_with_shadowing() {
	char guess[] = "Good Evening!!!";
	printf("Guess Value: %s", guess);

// Experiments.c:8:14: error: redefinition of ‘guess’
	// char guess[] = "Guten Tag!!!";
	// printf("Guess Value: %s", guess);	
}

//________________________________________________________

void play_with_int_values() {
	int some = 32;
	// long some = 32;

	printf("\nsome Value: %ld", some );
	some = 3123456789;
	printf("\nsome Value: %ld", some );
}

// Function : play_with_int_values
// some Value: 32
// some Value: -1171510507

// Function : play_with_int_values
// some Value: 32
// some Value: 3123456789

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

void main() {
	printf("\n\n\n Function : play_with_shadowing");
	play_with_shadowing();

	printf("\n\n\n Function : play_with_int_values");
	play_with_int_values();

	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
	// printf("\n\n\n Function : ");
}
