#![allow(unused)]

use std::fmt::Display;
use std::fmt::Debug;

//______________________________________________________________

fn largest_i32( list: &[i32] ) -> &i32 {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn largest_char(list: &[char]) -> &char {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

fn play_with_largest() {
    let number_list = vec![34, 50, 25, 100, 65];

    let result = largest_i32(&number_list);
    println!("The largest number is {result}");

    let char_list = vec!['y', 'm', 'a', 'q'];

    let result = largest_char(&char_list);
    println!("The largest char is {result}");
}

//______________________________________________________________

// What Is Template/Generics??
//		Generic : Code Which Will Generate Code
//			Code Generation Happens At Compile Time

// T Is Type Placeholder
//		Type PlaceHolder Will Get Substituted With Type At Compile Time
//			Compiler Will Susbtitute It!

/*
// <T> Means Telling Compiler Treat T As Type PlaceHolder
//		Hence T Substitued With i32
// Following Code Is Generated
fn largest_i32(list: &[i32]) -> &i32 {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }
    largest
}

//	Hence T Substitued With char
// Following Code Is Generated
fn largest_char(list: &[char]) -> &char {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }
    largest
}
*/

// Template Of Code
//		Type PlaceHolder Without Bounded Type
//			Hence T Can Be Substited With Any Type
// fn largest<T>(list: &[T]) -> &T {

//		Type PlaceHolder With Bounded Type
//		Type Bounds
//			Hence T Can Be Substited With Only Types Which Implements PartialOrd

// POLYMORPHIC FUNCTION -
//      USING MECHANISM - GENERIC FUNCTION
//      Compile Time Polymorphism
fn largest<T: std::cmp::PartialOrd>(list: &[T]) -> &T {
    let mut largest = &list[0];

    for item in list {
        if item > largest { 
        	// error[E0369]: binary operation `>` cannot be applied to type `&T`
            largest = item;
        }
    }
    largest
}

fn play_with_largest_generic() {
    // let number_list: [i32] = vec![34, 50, 25, 100, 65];
    let number_list = vec![34, 50, 25, 100, 65];
    let result = largest( &number_list );
    println!("The largest number is {}", result);

    // let char_list: [char] = vec!['y', 'm', 'a', 'q'];
    let char_list = vec!['y', 'm', 'a', 'q'];
    let result = largest(&char_list);
    println!("The largest char is {}", result);
}

//______________________________________________________________

// GENERIC STRUCTURE

struct Point<T> {
    x: T,
    y: T,
}

// Compiler Will Generate Code For Following Usage
    // let integer = Point { x: 5, y: 10 };

    // struct Point_i32 {
    //     x: i32,
    //     y: i32,
    // }

// Compiler Will Generate Code For Following Usage
    // let float = Point { x: 1.0, y: 4.0 };

    // struct Point_f64 {
    //     x: f64,
    //     y: f64,
    // }

fn play_with_point_generic() {
    let integer = Point { x: 5, y: 10 }; // Inferred Type Is i32 Hence T PlaceHolder Will Be i32 
    let float = Point { x: 1.0, y: 4.0 }; // Inferred Type Is f64 Hence T PlaceHolder Will Be f64
}

//______________________________________________________________

struct Point1<T, U> {
    x: T,
    y: U,
}

// Compiler Will Generate Equivalent Code Based On Per Usage
// struct Point1_i32_i32 {
//     x: i32,
//     y: i32,
// }

// struct Point1_f64_f64 {
//     x: f64,
//     y: f64,
// }

// struct Point1_i32_f64 {
//     x: i32,
//     y: f64,
// }

fn play_with_point_generic_multiple() {
    let both_integer 		= Point1 { x: 5, y: 10 }; // T Will Be i32 and U Will Be i32
    let both_float 			= Point1 { x: 1.0, y: 4.0 }; // T Will Be f64 and U Will Be f64
    let integer_and_float 	= Point1 { x: 5, y: 4.0 }; // T Will Be i32 and U Will Be f64
}

//______________________________________________________________

struct Point2<T> {
    x: T,
    y: T,
}

// Multi-Stage Implementation
//      Stage 01
// Generic Implementation Template For All T PlaceHolder Other Than f32
impl<T> Point2<T> {
	// Generic Method:: Definiing This Generic Method Using Type Place Holder T
    fn x(&self) -> &T {
        &self.x
    }
}

// Use Template When It's f32
impl Point2<f32> { // Specialised Implementaion Block PlaceHolder T == f32
    fn distance_from_origin(&self) -> f32 {
        (self.x.powi(2) + self.y.powi(2)).sqrt()
    }
}

fn play_with_point_generic2() {
    let p = Point2 { x: 5, y: 10 };

    println!("p.x = {}", p.x());
}


//______________________________________________________________

struct Point3<X1, Y1> {
    x: X1,
    y: Y1,
}

impl<X1, Y1> Point3<X1, Y1> {
    fn mixup<X2, Y2>(self, other: Point3<X2, Y2>) -> Point3<X1, Y2> {
        Point3 {
            x: self.x,
            y: other.y,
        }
    }
}

fn play_with_point_generic3() {
    let p1 = Point3 { x: 5, y: 10.4 };
    let p2 = Point3 { x: "Hello", y: 'c' };

    let p3 = p1.mixup(p2);

    println!("p3.x = {}, p3.y = {}", p3.x, p3.y);
}

//______________________________________________________________
// Generic Enums

enum Option<T> {
    Some(T),
    None,
}

enum Result<T, E> {
    Ok(T),
    Err(E),
}

//______________________________________________________________

/*
pub trait Summary {
    fn summarize(&self) -> String;
}

pub struct NewsArticle {
    pub headline: String,
    pub location: String,
    pub author: String,
    pub content: String,
}

impl Summary for NewsArticle {
    fn summarize(&self) -> String {
        format!("{}, by {} ({})", self.headline, self.author, self.location)
    }
}

pub struct Tweet {
    pub username: String,
    pub content: String,
    pub reply: bool,
    pub retweet: bool,
}

impl Summary for Tweet {
    fn summarize(&self) -> String {
        format!("{}: {}", self.username, self.content)
    }
}
*/

//______________________________________________________________

// Type Summary
//      Abstract Type
trait Summary {
    fn summarize(&self) -> String;
}

// Type NewsArticle
//      Concrete Type
struct NewsArticle {
    headline: String,
    location: String,
    author: String,
    content: String,
}

// Relationship : Type Of Type
// Implementing Summary Trait For NewsArticle Type
// NewsArticle Type Is Also Type Of Summary As Well As Display Type
impl Summary for NewsArticle {
    // Providing Implementation
    // fn summarize(&self) -> String;
    fn summarize(&self) -> String {
        format!("{}, by {} ({})", self.headline, self.author, self.location)
    }
}

impl Display for NewsArticle {
    // Providing Implementation
    // fn summarize(&self) -> String;
    // fn summarize(&self) -> String {
    //     format!("{}, by {} ({})", self.headline, self.author, self.location)
    // }

    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        // Write strictly the first element into the supplied output
        // stream: `f`. Returns `fmt::Result` which indicates whether the
        // operation succeeded or failed. Note that `write!` uses syntax which
        // is very similar to `println!`.
        write!(f, "{}", self.headline)
    }
}

// Type Tweet
//      Concrete Type
struct Tweet {
    username: String,
    content: String,
    reply: bool,
    retweet: bool,
}

// Relationship : Type Of Type
// Tweet Type Is Also Summary Type
impl Summary for Tweet {
    fn summarize(&self) -> String {
        format!("{}: {}", self.username, self.content)
    }
}

fn play_with_traits() {
    let article = NewsArticle {
                headline: "String...".to_string(),
                location: "String...".to_string(),
                author: "String...".to_string(),
                content: "String.....".to_string(),
            };

    let tweet = Tweet {
        username: "Gabbar Singh".to_string(),
        content: "How are you doing?".to_string(),
        reply: true,
        retweet: true,
    };

    let result = article.summarize();
    println!("Result : {result}" );

    let result = tweet.summarize();
    println!("Result : {result}" );

    notify( &article );
    notify( &tweet );    
}

//______________________________________________________________


// Polymorphic Function
// Using Mechanims : Function Overloading
// error[E0428]: the name `notify` is defined multiple times
// fn notify( item: &NewsArticle) {
//     println!("Breaking news! {}", item.summarize());
// }

// fn notify( item: &Tweet) {
//     println!("Breaking news! {}", item.summarize());
// }

// POLYMORPHIC FUNCTION
//      USING MECHANIMS - TRAITS
//      Runtime Polymorphism
fn notify( item: &impl Summary ) {
    println!("Breaking news! {}", item.summarize());
}


// OR USE FOLLOWING ONE
// POLYMORPHIC FUNCTION
//      USING MECHANIMS - GENERICS

fn notify_again<T : Summary>( item: &T ) {
    println!("Breaking news! {}", item.summarize());
}


fn notify2(item1: &impl Summary, item2: &impl Summary) {

}

fn notify3( item: &(impl Summary + Display)) {

}

fn notify3_again<T: Summary + Display>(item: &T) {

}

// Following Display Trait Comes From std::fmt::Display
// pub trait Display {
//     // Required method
//     fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), Error>;
// }

// REFERENCE LINK: https://doc.rust-lang.org/std/fmt/trait.Display.html


//______________________________________________________________
// Following Both Are Equivalent

fn some_function<T: Display + Clone, U: Clone + Debug>( t: &T, u: &U ) -> i32 
{
    99
}

// Far More Readable Syntax
fn some_function_again<T, U>(t: &T, u: &U) -> i32
where
    T: Display + Clone,
    U: Clone + Debug,
{
    99
}

//______________________________________________________________

// trait Type FlyingType
// trait Type SingingType

// struct Type HumanType

// Type HumanType Also Be Type FlyingType
// Type HumanType Also Be Type SingingType

//______________________________________________________________

// Manager Type Of Employee Type Of Human
// Manager Type Of Employee Type Of Citizen

//______________________________________________________________

// use std::fmt::Display;

struct Pair<T> {
    x: T,
    y: T,
}

impl<T> Pair<T> {
    fn new(x: T, y: T) -> Self {
        Self { x, y }
    }
}

impl<T: Display + PartialOrd> Pair<T> {
    fn cmp_display(&self) {
        if self.x >= self.y {
            println!("The largest member is x = {}", self.x);
        } else {
            println!("The largest member is y = {}", self.y);
        }
    }
}

//______________________________________________________________

/*
impl<T: Display> ToString for T {
    // --snip--
}
*/

// std::string

// pub trait ToString {
//     // Required method
//     fn to_string(&self) -> String;
// }

// A trait for converting a value to a String.
// This trait is automatically implemented for any type which 
//      implements the Display trait. As such, 
//      ToString shouldn’t be implemented directly: 
//      Display should be implemented instead, and you get the 
//      ToString implementation for free.

//______________________________________________________________

use std::fmt;

struct PointAgain {
    x: i32,
    y: i32,
}

impl fmt::Display for PointAgain {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "({}, {})", self.x, self.y)
    }
}

fn play_with_display_trait() {
    let origin = PointAgain { x: 0, y: 0 };

    assert_eq!(format!("The origin is: {origin}"), "The origin is: (0, 0)");
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
	println!("\n\n\nFunction : play_with_largest");
	play_with_largest();

	println!("\n\n\nFunction : play_with_largest_generic");
	play_with_largest_generic();

	println!("\n\n\nFunction : play_with_point_generic");
	play_with_point_generic();

	println!("\n\n\nFunction : play_with_point_generic_multiple");
	play_with_point_generic_multiple();

	println!("\n\n\nFunction : play_with_point_generic2");
	play_with_point_generic2();

	println!("\n\n\nFunction : play_with_point_generic3");
	play_with_point_generic3();

	println!("\n\n\nFunction : play_with_traits");
    play_with_traits();

    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

