
import java.util.ArrayList;

// Structure Programming
//		State Driven Programming: State First

// Object Oriented Programming
//		Behaviour Driven Programming: Behavior First

// Interface Driven Design
//		Prefer Interface Over Concrete Classes

// Communication Protocol
//		Forces A Contract On Participating Objects
//							Communication

// WHAT TO DO 
// Type Superpower
//		Mathemcatically Abstract Type :: Abstraction
//			It Has Operation Set and Range Set Will Empty
//		Operation = { fly(), saveWorld() }
//		Range 	  = { } Empty

// In C++ Pure Abstract Classes
// In Rust Using Trait
//		Behaviour First
//		Interface Driven Programming
interface Superpower { 
	public void fly();
	public void saveWorld();
}

// HOW, WHEN, WHICH WAY TO DO
// Type Spiderman
//		Type To Type Relationship
//			Spiderman Type Is Also Superpower Type 
class Spiderman implements Superpower {
	public void fly() { System.out.println("Spiderman: Flying"); } 
	public void saveWorld() { System.out.println("Spiderman: Saving"); } 
}

//	Type To Type Relationship
//		Spiderman Type Is Also Superpower Type 
class Superman implements Superpower {
	public void fly() { System.out.println("Superman: Flying"); } 
	public void saveWorld() { System.out.println("Superman: Saving"); } 
}

//		Type To Type Relationship
//			Spiderman Type Is Also Superpower Type 
class Wonderman implements Superpower {
	public void fly() { System.out.println("Wonderman: Flying"); } 
	public void saveWorld() { System.out.println("Wonderman: Saving"); } 
}

// Inheritance
// class Human extends Spiderman {
class Human extends Superman {
	public void fly() 		{ super.fly(); 		 }		// { System.out.println("Human: Flying"); } 
	public void saveWorld() { super.saveWorld(); }		// { System.out.println("Human: Saving"); } 
}
// BEST PRACTICE
//		Always Prefer Composition Over Inheritance

// Composition Design Pattern
// Type HumanBetter
//		Polymorphic Type
//		Substraction Is Possible
class HumanBetter {
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	Superpower power = null;
	public void fly() 		{ if (power != null) power.fly(); }		// { System.out.println("Human: Flying"); } 
	public void saveWorld() { if (power != null) power.saveWorld();  }		// { System.out.println("Human: Saving"); } 
}

public class HumanDemo {
	public static void main( String[] args) {
		System.out.println("Hello.");
	
		Human human = new Human();
		human.fly();
		human.saveWorld();

		HumanBetter humanb = new HumanBetter();
		humanb.power = new Spiderman();
				// incompatible types: Spiderman cannot be converted to Superpower
		humanb.fly();
		humanb.saveWorld();

		humanb.power = new Superman();
		humanb.fly();
		humanb.saveWorld();

		humanb.power = new Wonderman();
		humanb.fly();
		humanb.saveWorld();

		ArrayList<Superpower> powers = new ArrayList<Superpower>();

		powers.add( new Spiderman() );
		powers.add( new Superman() ) ;
		powers.add( new Wonderman() ) ;

		for (Superpower power : powers) {
            // System.out.print(e + " ");
			power.fly();
			power.saveWorld();
        }
	} 
}

