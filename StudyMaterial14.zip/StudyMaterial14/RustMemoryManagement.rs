
//______________________________________________________________
//______________________________________________________________

use std::mem;

#[allow(dead_code)]
#[derive(Debug, Clone, Copy)]
struct Point {
    x: f64,
    y: f64,
}

// A Rectangle can be specified by where its top left and bottom right 
// corners are in space
#[allow(dead_code)]
struct Rectangle {
    top_left	: Point,
    bottom_right: Point,
}

fn origin() -> Point {
    Point { x: 0.0, y: 0.0 }
}

fn boxed_origin() -> Box<Point> {
    // Allocate this point on the heap, and return a pointer to it
    Box::new( Point { x: 0.0, y: 0.0 } )
}

fn play_with_box() {
    // (all the type annotations are superfluous)
    // Stack allocated variables
    let point: Point = origin();

    let rectangle: Rectangle = Rectangle {
        top_left: origin(),
        bottom_right: Point { x: 3.0, y: -4.0 }
    };

    // Heap allocated rectangle
    let boxed_rectangle: Box<Rectangle> = Box::new(Rectangle {
        top_left: origin(),
        bottom_right: Point { x: 3.0, y: -4.0 },
    });

    // The output of functions can be boxed
    let boxed_point: Box<Point> = Box::new(origin());

    // Double indirection
    let box_in_a_box: Box<Box<Point>> = Box::new( boxed_origin() );

    println!("Point occupies {} bytes on the stack",
             mem::size_of_val(&point));
    println!("Rectangle occupies {} bytes on the stack",
             mem::size_of_val(&rectangle));

    // box size == pointer size
    println!("Boxed point occupies {} bytes on the stack",
             mem::size_of_val(&boxed_point));
    println!("Boxed rectangle occupies {} bytes on the stack",
             mem::size_of_val(&boxed_rectangle));
    println!("Boxed box occupies {} bytes on the stack",
             mem::size_of_val(&box_in_a_box));

    // Copy the data contained in `boxed_point` into `unboxed_point`
    let unboxed_point: Point = *boxed_point;
    println!("Unboxed point occupies {} bytes on the stack",
             mem::size_of_val(&unboxed_point));
}

//______________________________________________________________

// When dealing with resources, the default behavior is to transfer 
// them during assignments or function calls. 
// However, sometimes we need to make a copy of the resource as well.

// The Clone trait helps us do exactly this. 
// Most commonly, we can use the .clone() method defined by the Clone trait.

// A unit struct without resources
#[derive(Debug, Clone, Copy)]
struct Unit;

// A tuple struct with resources that implements the `Clone` trait
#[derive(Clone, Debug)]
struct Pair(Box<i32>, Box<i32>);

fn play_with_clone_again() {
    // Instantiate `Unit`
    let unit = Unit;
    // Copy `Unit`, there are no resources to move

    let copied_unit = unit;

    // Both `Unit`s can be used independently
    println!("original: {:?}", unit);
    println!("copy: {:?}", copied_unit);

    // Instantiate `Pair`
    let pair = Pair(Box::new(1), Box::new(2));
    println!("original: {:?}", pair);

    // Move `pair` into `moved_pair`, moves resources
    let moved_pair = pair;
    println!("moved: {:?}", moved_pair);

    // Error! `pair` has lost its resources
    // println!("original: {:?}", pair);
    // TODO ^ Try uncommenting this line

    // Clone `moved_pair` into `cloned_pair` (resources are included)
    let cloned_pair = moved_pair.clone();
    // Drop the moved original pair using std::mem::drop
    drop(moved_pair);

    // Error! `moved_pair` has been dropped
    // println!("moved and dropped: {:?}", moved_pair);
    // TODO ^ Try uncommenting this line

    // The result from .clone() can still be used!
    println!("clone: {:?}", cloned_pair);
    println!("clone: {} {}", cloned_pair.0, cloned_pair.1);

}

//______________________________________________________________

// Differs from Copy in that Copy is implicit and an inexpensive bit-wise copy, 
//      while Clone is always explicit and may or may not be expensive. 

// In order to enforce these characteristics, Rust does not allow you to 
//  reimplement Copy, but you may reimplement Clone and run arbitrary code.

// Since Clone is more general than Copy, 
//  you can automatically make anything Copy be Clone as well.

// pub trait Clone: Sized {
//     // Required method
//     fn clone(&self) -> Self;

//     // Provided method
//     fn clone_from(&mut self, source: &Self) { ... }
// }


//______________________________________________________________

// std::ops
// pub trait Drop {
//     // Required method
//     const fn drop(&mut self);
// }

// Custom code within the destructor.

// When a value is no longer needed, Rust will run a “destructor” on that value. 
//  The most common way that a value is no longer needed is 
//  when it goes out of scope.

// Destructors may still run in other circumstances, 
// but we’re going to focus on scope for the examples here. 
// To learn about some of those other cases, 
// please see the reference section on destructors.

// This destructor consists of two components:

// A call to Drop::drop for that value, if this 
//      special Drop trait is implemented for its type.
// The automatically generated “drop glue” which recursively calls 
//      the destructors of all the fields of this value.

//______________________________________________________________

#[derive(Debug)]
struct HasDrop;

impl Drop for HasDrop {
    fn drop(&mut self) {
        println!("Dropping HasDrop!");
    }
}

// Composition Pattern
#[derive(Debug)]
struct HasTwoDrops {
    one: HasDrop,
    two: HasDrop,
}

impl Drop for HasTwoDrops {
    fn drop(&mut self) {
        println!("Dropping HasTwoDrops!");
    }
}

fn play_with_dropping_order() {
    let x = HasTwoDrops { one: HasDrop, two: HasDrop };
    println!("Running!");
    println!("Values {:?} {:?}", x.one, x.two);

} // _x Life Time Get Overs On This Scope End

// Function : play_with_dropping_order
// Running!
// Dropping HasTwoDrops!
// Dropping HasDrop!
// Dropping HasDrop!

//______________________________________________________________

#[derive(Debug)]
struct Droppable {
    name: &'static str,
}

// This trivial implementation of `drop` adds a print to console.
impl Drop for Droppable {
    fn drop(&mut self) {
        println!("> Dropping {}", self.name);
    }
}

fn play_with_trait_drop() {
    let _a = Droppable { name: "aaa" };

    // block A
    {
        let _b = Droppable { name: "bbb" };

        // block B
        {
            let _c = Droppable { name: "ccc" };
            let _d = Droppable { name: "ddd" };

            println!("Exiting block B");
        }
        println!("Just exited block B");

        println!("Exiting block A");
    }
    println!("Just exited block A");

    // Variable can be manually dropped using the `drop` function
    drop(_a);
    // TODO ^ Try commenting this line

    println!("end of the main function");

    // `_a` *won't* be `drop`ed again here, because it already has been
    // (manually) `drop`ed
}

// Function : play_with_trait_drop
// Exiting block B
// > Dropping d
// > Dropping c
// Just exited block B
// Exiting block A
// > Dropping b
// Just exited block A
// > Dropping a
// end of the main function


//______________________________________________________________

// The Drop trait only has one method: 
//  drop, which is called automatically when an object 
//  goes out of scope. 

//  The main use of the Drop trait is to free the resources 
//  that the implementor instance owns.

// Box, Vec, String, File, and Process are some examples of types 
//      that implement the Drop trait to free resources. 
//  The Drop trait can also be manually implemented for any custom data type.

//______________________________________________________________

use std::fs::File;
use std::path::PathBuf;

#[derive(Debug)]
struct TempFile {
    file: File,
    path: PathBuf,
}

impl TempFile {
    fn new(path: PathBuf) -> std::io::Result<Self> {
        // Note: File::create() will overwrite existing files
        let file = File::create(&path)?;
        
        Ok(Self { file, path })
    }
}

// When TempFile is dropped:
// 1. First, the File will be automatically closed (Drop for File)
// 2. Then our drop implementation will remove the file
impl Drop for TempFile {
    fn drop(&mut self) {
        // Note: File is already closed at this point
        if let Err(e) = std::fs::remove_file(&self.path) {
            eprintln!("Failed to remove temporary file: {}", e);
        }
        println!("> Dropped temporary file: {:?}", self.path);
    }
}

fn play_with_trait_drop_again() -> std::io::Result<()> {
    // Create a new scope to demonstrate drop behavior
    {
        let temp = TempFile::new("test.txt".into())?;
        println!("Temporary file created");
        println!("{:?} {:?}", temp.file, temp.path)        
        // File will be automatically cleaned up when temp goes out of scope
    }
    println!("End of scope - file should be cleaned up");

    // We can also manually drop if needed
    let temp2 = TempFile::new("another_test.txt".into())?;
    drop(temp2); // Explicitly drop the file
    println!("Manually dropped file");
    
    Ok(())
}

//______________________________________________________________

use std::rc::Rc;

fn play_with_reference_counting() {
    let rc_examples = "Rc examples".to_string();

    {
        println!("--- rc_a is created ---");

        // let _a: String = String::new(rc_examples);
        
        let rc_a: Rc<String> = Rc::new(rc_examples);
        println!("Reference Count of rc_a: {}", Rc::strong_count(&rc_a));

        // --- rc_a is created ---
        // Reference Count of rc_a: 1        
        {
            println!("--- rc_a is cloned to rc_b ---");
            
            let rc_b: Rc<String> = Rc::clone(&rc_a);
            println!("Reference Count of rc_b: {}", Rc::strong_count(&rc_b));
            println!("Reference Count of rc_a: {}", Rc::strong_count(&rc_a));

// --- rc_a is cloned to rc_b ---
// Reference Count of rc_b: 2
// Reference Count of rc_a: 2
            
            // Two `Rc`s are equal if their inner values are equal
            println!("rc_a and rc_b are equal: {}", rc_a.eq(&rc_b));
// rc_a and rc_b are equal: true
            
            // We can use methods of a value directly
            println!("Length of the value inside rc_a: {}", rc_a.len());
            println!("Value of rc_a: {}", rc_a);
            println!("Length of the value inside rc_b: {}", rc_b.len());
            println!("Value of rc_b: {}", rc_b);

// Length of the value inside rc_a: 11
// Value of rc_a: Rc examples
// Length of the value inside rc_b: 11
// Value of rc_b: Rc examples
            
            println!("--- rc_b is dropped out of scope ---");
        }
        
        println!("Reference Count of rc_a: {}", Rc::strong_count(&rc_a));
        println!("--- rc_a is dropped out of scope ---");
    }
    
    // Error! `rc_examples` already moved into `rc_a`
    // And when `rc_a` is dropped, `rc_examples` is dropped together
    // println!("rc_examples: {}", rc_examples);
    // TODO ^ Try uncommenting this line
}

// Function : play_with_reference_counting
// --- rc_a is created ---
// Reference Count of rc_a: 1
// --- rc_a is cloned to rc_b ---
// Reference Count of rc_b: 2
// Reference Count of rc_a: 2
// rc_a and rc_b are equal: true
// Length of the value inside rc_a: 11
// Value of rc_b: Rc examples
// --- rc_b is dropped out of scope ---
// Reference Count of rc_a: 1
// --- rc_a is dropped out of scope ---

//______________________________________________________________

// Reference Couting: Rc

// When multiple ownership is needed, 
//      Rc(Reference Counting) can be used. 
//      Rc keeps track of the number of the references which means 
//      the number of owners of the value wrapped inside an Rc.

// Reference count of an Rc increases by 1 whenever 
//      an Rc is cloned, and decreases by 1 whenever 
//      one cloned Rc is dropped out of the scope. 
//      When an Rc's reference count becomes zero 
//      (which means there are no remaining owners), 
//      both the Rc and the value are all dropped.

// Cloning an Rc never performs a deep copy. 
//      Cloning creates just another pointer to the wrapped value, 
//      and increments the count.

//______________________________________________________________

// Arc

// When shared ownership between threads is needed, 
//      Arc(Atomically Reference Counted) can be used. 
//      This struct, via the Clone implementation can create 
//      a reference pointer for the location of a value in the 
//      memory heap while increasing the reference counter. 
//     As it shares ownership between threads, when the last reference 
//      pointer to a value is out of scope, the variable is dropped.

//______________________________________________________________

use std::time::Duration;
use std::sync::Arc;
use std::thread;

fn play_with_arc() {
    // This variable declaration is where its value is specified.
    let apple = Arc::new("The Same Apple");

    for _ in 0..10 {
        // Here there is no value specification as it is a pointer to a
        // reference in the memory heap.
        let apple = Arc::clone(&apple);

        thread::spawn(  move || {
                // As Arc was used, threads can be spawned 
                // using the value allocated
                // in the Arc variable pointer's location.
                println!("{:?}", apple);
            }
        );
    }

    // Make sure all Arc instances are printed from spawned threads.
    thread::sleep( Duration::from_secs(1) );
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
    println!("\n\n\nFunction : play_with_box");
    play_with_box();

    println!("\n\n\nFunction : play_with_clone_again");
    play_with_clone_again();

    println!("\n\n\nFunction : play_with_dropping_order");
    play_with_dropping_order();

    println!("\n\n\nFunction : play_with_trait_drop");
    play_with_trait_drop();

    println!("\n\n\nFunction : play_with_trait_drop_again");
    let _ = play_with_trait_drop_again();

    println!("\n\n\nFunction : play_with_reference_counting");
    play_with_reference_counting();

    println!("\n\n\nFunction : play_with_arc");
    play_with_arc();

    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
}

