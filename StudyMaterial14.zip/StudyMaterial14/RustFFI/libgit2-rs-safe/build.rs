
fn main() {
//  println!(r"cargo:rustc-link-search=native=/home/jimb/libgit2-0.25.1/build");
    println!(r"cargo:rustc-link-search=native=/home/amarjit/Documents/Experiments/libgit2-0.25.1/build");
}

/*

export LD_LIBRARY_PATH=/home/amarjit/Documents/Experiments/libgit2-0.25.1/build:$LD_LIBRARY_PATH

*/



// fn main() {
//     println!("cargo:rustc-link-search=native=/home/jimb/libgit2-0.25.1/build");
// }
