#![allow(unused)]
//______________________________________________________________

// Creating Type IpAddrKind
//		Set Of Value 		= { V4, V6 }
//		Set Of Operation 	= { }
enum IpAddrKind {
	V4,
	V6,
}

fn route( ip_kind: IpAddrKind ) {
	// Dummy Function Code Goes Here...
}

fn play_with_ipaddress_enum() {
	let four = IpAddrKind::V4;
	let six = IpAddrKind::V6;

	route( IpAddrKind::V4 );
	route( IpAddrKind::V6 );
}

//______________________________________________________________

fn play_with_ipaddress_enum1() {
	// Associative Types
	//		Sum Type
    enum IpAddrKind {
        V4,
        V6,
    }
	// Associative Types
	//		Product Type
    struct IpAddr {
    	// Composing 
        kind: IpAddrKind,  // 2
        address: String,   // 225 * 255 * 255 * 255
    }

    let some: IpAddrKind = IpAddrKind::V4;
    // let some_again: IpAddr = ???; // 2 * 225 * 255 * 255 * 255

    let home = IpAddr {
        kind: IpAddrKind::V4,
        address: String::from("127.0.0.1"),
    };

    let loopback = IpAddr {
        kind: IpAddrKind::V6,
        address: String::from("::1"),
    };
}

//______________________________________________________________

fn play_with_ipaddress_enum2() {
	// Associative Types
	//		Sum Type
    enum IpAddr {
        V4(String), // Enum Constant Can Have Further State
        V6(String),
    }

    let home = IpAddr::V4( String::from("127.0.0.1") );
    let loopback = IpAddr::V6(String::from("::1"));
    // let some : IpAddr = 3;    
}

//______________________________________________________________

fn play_with_ipaddress_enum3() {
	#[derive(Debug)]
	#[derive(PartialEq)]
    enum IpAddr {
        V4(u8, u8, u8, u8),
        V6(String),
    }

    let home = IpAddr::V4(127, 0, 0, 1);
    let loopback = IpAddr::V6(String::from("::1"));

	let home1 = IpAddr::V4(127, 1, 1, 1);

	let result = home == home1;
    println!("Result : {:?}", result);

    println!("Value : {:?}", home);
    // let (part1, part2, part3, part4): IpAddr = home;

    // println!("Value : {loopback}");
}

//______________________________________________________________

fn play_with_ipaddress_enum4() {
    struct Ipv4Addr {
        // --snip--
        // part1: u8,
        // part2: u8,
        // part3: u8,
        // part4: u8,
    }

    struct Ipv6Addr {
        // --snip--
    }

    enum IpAddr {
        V4(Ipv4Addr),
        V6(Ipv6Addr),
    }
}

//______________________________________________________________

fn play_with_message_enum() {

// Creating Type Message
//		Set Of Value 		= { Quit, Move, Write, ChangeColor }
//		Set Of Operation 	= { call() }

// Associative Types
//		Sum Type
// BEST PRACTICE: 
//		Always Use Sum Types Over Product Types To Simulate Domain Knowledge
    
    enum Message {
    	Join,
        Quit,
        Move { x: i32, y: i32 },
        Write(String),
        ChangeColor(i32, i32, i32),
    }

    impl Message {
    	// Methods
        fn call(&self) {
            // method body would be defined here
        }
    }

    let m = Message::Write(String::from("hello"));
    m.call();
}

    // // In C++
    // enum MessageType {
    // 	Join,
    // 	Quit
    // }

    // struct Point {
    // 	x: i32, 
    // 	y: i32,
    // }

    // struct Color {
    // 	r: i32, 
    // 	g: i32, 
    // 	b: i32,
    // }

    // // Product Types
    // struct Message {
    //     join: MessageType
    //     quit: MessageType,
    //     write: String,
    //     change_color: Color,'
    //     move: Point ,
    // }

    // let posting = Message {
    // 	join: Null,
    // 	quit: Null,
    // 	write: "Hello I am new to Rust!",
    // 	change_color: (99, 99, 99),
    // 	move: (10, 10),
    // }

    // let join = Message {
    // 	join: "Joined 90349039403",
    // 	quit: Null,
    // 	write: Null,
    // 	change_color: (99, 99, 99),
    // 	move: (10, 10),
    // }

    // let quit = Message {
    // 	join: Null,
    // 	quit: "90349039403 Left",
    // 	write: Null,
    // 	change_color: (99, 99, 99),
    // 	move: (10, 10),
    // }

    // let some_message = Message {
    // 	join: "Joined 90349039403",
    // 	quit: "90349039403 Left",
    // 	write: Null,
    // 	change_color: (99, 99, 99),
    // 	move: (10, 10),
    // }


//______________________________________________________________

fn play_with_optional() {
    let some_number = Some(5);
    let some_char = Some('e');

    let absent_number: Option<i32> = None;
}

/*
fn sum( a: i32, b: i32 ) -> i32 {

}

fn sum( a: i32, b: i32 ) -> Option<i32> {

}
*/

//______________________________________________________________

fn play_with_optionals() {
    let some_number = Some(5);
    let some_char = Some('e');

    let absent_number: Option<i32> = None;

    let x: i8 = 5;
    let y: Option<i8> = Some(5);

    // let sum = x + y;
}

//______________________________________________________________

// In C/C++
//	switch( Expression ) {  
//			case x:
//			case y:
//			default:
//	}

// Respecting Type Definition Like God!
// Coin Type
//		Range = { Penny, Nickel, Dime, Quarter }
//		Operation = {}
enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter,
}

// Deterministic Code
//		Type Safe Code
//			Respecting Type Definition Like God!
fn value_in_cents(coin: Coin) -> u8 {
	// coin Is Of Coin Type
	// match Is Type Safe Expression
	//		It Has Return Value
    match coin {
        Coin::Penny 	=> 1,
        Coin::Nickel 	=> 5,
        Coin::Dime 		=> 10,
        Coin::Quarter 	=> 25, 
        // ^^^^ pattern `Coin::Quarter` not covered
        // ^^ expected `Coin`, found integer
        // 99 				=> 100,
    }
}

fn value_in_cents1(coin: Coin) -> u8 {
	// match Is An Expression
	//		Expression Is A Statement With Value
	//		Expression Has Value    
	//		Every Value Has Type
    match coin {
        Coin::Penny 	=> {
            					println!("Lucky penny!");
            					1
            					// "Hello"
        			   		}
        Coin::Nickel 	=> 5,
        Coin::Dime 		=> 10,
        Coin::Quarter 	=> 25,
        // Coin::Quarter 	=> "Hello",
         // ^^^^^^^ expected `u8`, found `&str`
    }
}

fn play_with_coins() {
    println!("Value : {}", value_in_cents( Coin::Penny ));
    println!("Value : {}", value_in_cents( Coin::Dime ));
    println!("Value : {}", value_in_cents( Coin::Quarter ));

    println!("Value : {}", value_in_cents1( Coin::Penny ));
    println!("Value : {}", value_in_cents1( Coin::Dime ));
    println!("Value : {}", value_in_cents1( Coin::Quarter ));
}

//______________________________________________________________

// pub enum Option<T> {
//     None,
//     Some(T), // Wrapped Value Inside Bucket
// }

fn play_with_returing_optional() {
    fn plus_one(x: Option<i32>) -> Option<i32> {
        match x {
            None 	=> None,
            Some(i) => Some(i + 1),
        }
    }

    let five 	= Some(5);
    let six 	= plus_one(five);
    let none 	= plus_one(None);

    // fn plus_one_again(x: Option<i32>) -> Option<i32> {
    //     match x {
    //     	 // ^ pattern `None` not covered
    //         Some(i) => Some(i + 1),
    //     }
    // }

    // let five1 = Some(5);
    // let six1 = plus_one_again(five);
    // let none1 = plus_one_again(None);
}

//______________________________________________________________


fn play_with_match_default() {
    let dice_roll = 9;

    match dice_roll {
        3 		=> add_fancy_hat(),
        7 		=> remove_fancy_hat(),
        other 	=> move_player(other), // Default Case
// ^^^^^^^^^ patterns `i32::MIN..=2_i32`, `4_i32..=6_i32` and `8_i32..=i32::MAX` not covered
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn move_player(num_spaces: u8) {}
}

//_________________________________________________________

fn play_with_match_underscore() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => reroll(),
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn reroll() {}
}

//_________________________________________________________

fn play_with_match_underscore1() {
    let dice_roll = 9;

    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => (),
        // _ => 99,

    }

    fn add_fancy_hat() 		{		}
    fn remove_fancy_hat() 	{		}
}

// error[E0308]: `match` arms have incompatible types
//    --> RustEnums.rs:378:14
//     |
// 374 | /     match dice_roll {
// 375 | |         3 => add_fancy_hat(),
//     | |              --------------- this is found to be of type `()`
// 376 | |         7 => remove_fancy_hat(),
//     | |              ------------------ this is found to be of type `()`
// 377 | |         // _ => (),
// 378 | |         _ => 99,
//     | |              ^^ expected `()`, found integer
// 379 | |
// 380 | |     }
//     | |_____- `match` arms have incompatible types

//______________________________________________________________

/*
struct Dog(i32);
struct Cat(u8);

enum Animal {
    Dog(Dog),
    Cat(Cat),
}

impl Animal {
    fn cat(self) -> Cat {
        if let Animal::Cat(c) = self {
            c
        } else {
            panic!("Not a cat")
        }
    }

    fn dog(self) -> Dog {
        if let Animal::Dog(d) = self {
            d
        } else {
            panic!("Not a dog")
        }
    }
}

impl Animal {
    fn cat(self) -> Option<Cat> {
        match self {
            Animal::Cat(c) => Some(c),
            _ => None,
        }
    }

    fn dog(self) -> Option<Dog> {
        match self {
            Animal::Dog(d) => Some(d),
            _ => None,
        }
    }
}

// Or better an impl on `Cat` ?
fn count_legs_of_cat(c: Cat) -> u8 {
    c.0
}
*/

//______________________________________________________________

#[derive(Debug)]
enum TypeWrapper {
    Alphanum(String),
    Letter(char),
    Integer(i64),
    Floating(f64),
}

impl TypeWrapper {
    fn util_extract_typewrapper(value: TypeWrapper) -> String {
        match value {
            TypeWrapper::Alphanum(i) 	=> i,
            TypeWrapper::Letter(i)		=> i.to_string(),
            TypeWrapper::Integer(i) 	=> i.to_string(),
            TypeWrapper::Floating(i) 	=> i.to_string(),
        }
    }
}

fn play_with_enum_inner_values() {
    let something = TypeWrapper::Letter('m');
    println!("\n The wrapped up value is:   {:?} \n", something);

    let value = TypeWrapper::util_extract_typewrapper(something);
    println!("\n The value as a String is :   {} \n", value);
    
    value.chars().next().unwrap();
    println!("\n The value as a char is :   {} \n", value);
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fn main() {
	println!("\n\n\nFunction : play_with_ipaddress_enum");
	play_with_ipaddress_enum();

	println!("\n\n\nFunction : play_with_ipaddress_enum1");
	play_with_ipaddress_enum1();

	println!("\n\n\nFunction : play_with_ipaddress_enum3");
	play_with_ipaddress_enum3();

	println!("\n\n\nFunction : play_with_ipaddress_enum4");
	play_with_ipaddress_enum4();

	println!("\n\n\nFunction : play_with_message_enum");
	play_with_message_enum();

	println!("\n\n\nFunction : play_with_optional");
	play_with_optional();

	println!("\n\n\nFunction : play_with_optionals");
	play_with_optionals();

	println!("\n\n\nFunction : play_with_match_default");
	play_with_match_default();

	println!("\n\n\nFunction : play_with_match_underscore");
	play_with_match_underscore();

	println!("\n\n\nFunction : play_with_match_underscore1");
	play_with_match_underscore1();

	// println!("\n\n\nFunction : count_legs_of_cat");
	// count_legs_of_cat();

	println!("\n\n\nFunction : play_with_enum_inner_values");
	play_with_enum_inner_values();


	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

