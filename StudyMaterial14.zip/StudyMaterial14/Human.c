
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
	// void doHipHop() {
	// 	printf("\nDoing Hip Hop Dance..");
	// }
} Human;

void doHipHop() {
	printf("\nDoing Hip Hop Dance..");
}

void doSomeDance() {
	printf("\nDoing Some Dance..");
}

int main() {
	Human aymen = {100, "Aymen Mohaumod", doSomeDance};
	printf("\nID 	: %d", aymen.id );
	printf("\nName 	: %s", aymen.name );
	aymen.dance();

	Human alice = {111, "Alice Carol", doHipHop};
	printf("\nID 	: %d", alice.id );
	printf("\nName 	: %s", alice.name );
	alice.dance();
}

 
// 1. Abstraction
// 2. Encapuslation
// 3. Inheritance
// 4. Polymorpism
