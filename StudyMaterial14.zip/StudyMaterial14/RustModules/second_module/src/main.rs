
// This declaration will look for a file named `my.rs` and will
// insert its contents inside a module named `my` under this scope
mod my;

//use my::inaccessible;

fn function() {
    println!("called `function()`");
}

fn main() {
    my::function();

    function();

    my::indirect_access();

    my::function();
    //my::nested::function();

    //error[E0603]: module `inaccessible` is private
    my::inaccessible::function();
}

//fn main() {
//   println!("Hello, world!");
//}
