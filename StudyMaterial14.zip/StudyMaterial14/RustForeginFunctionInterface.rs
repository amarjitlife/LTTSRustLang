
//______________________________________________________________

// Rust’s foreign function interface (FFI) 
//		lets Rust code call functions written in C, 
//		and in some cases C++. 
//		Since most operating systems offer C interfaces, 

// Rust’s foreign function interface allows 
//		immediate access to all sorts of low-level facilities

// String In Rust
//		 "Hello World\0Hello"

// C has always been sur‐prisingly loose about 
// 		its types’ representations: 
//			an int is typically 32 bits long, 
//			but could be longer, 
//			or as short as 16 bits; 

// C char may be signed or unsigned; and so on.

// To cope with this variability, 
//		Rust’s std::os::raw module defines a set of Rust types
// 		that are guaranteed to have the same representation as 
//		certain C types

// Table 23-1. std::os::raw types in Rust
// C type 					Corresponding std::os::raw type
// short 						c_short
// int 							c_int
// long 						c_long
// long long 					c_longlong
// unsigned short 				c_ushort
// unsigned, unsigned int 		c_uint
// unsigned long 				c_ulong
// unsigned long long 			c_ulonglong
// char 						c_char
// signed char 					c_schar
// unsigned char 				c_uchar
// float						c_float
// double 						c_double
// void *, const void **mut 	c_void, *const c_void

//______________________________________________________________

// Except for c_void, all the Rust types here are aliases for 
// some primitive Rust type:
// c_char, for example, is either i8 or u8.

// A Rust bool is equivalent to a C or C++ bool.

// Rust’s 32-bit char type is not the analogue of wchar_t, 
// whose width and encoding vary from one implementation to another. 
//  	C’s char32_t type is closer, but its encoding is still 
//		not guaranteed to be Unicode.

// Rust’s primitive usize and isize types have the same 
// representations as C’s size_t and ptrdiff_t.

// C and C++ pointers and C++ references correspond to 
//		Rust’s raw pointer types, *mut T and *const T.

// Technically, the C standard permits implementations to use 
// representations for which Rust has no corresponding type: 36-bit integers, 
//		sign-and-magnitude rep‐resentations for signed values, and so on. 

// In practice, on every platform Rust has
// 		been ported to, every common C integer type has a match in Rust.

// C Code
typedef struct {
	char *message;
	int klass;
} git_error;


// In Rust
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct git_error {
	pub message: *const c_char,
	pub klass: c_int
}

// The #[repr(C)] attribute affects only the layout of the struct itself, not the represen‐
// tations of its individual fields, so to match the C struct, each field must use the C-like
// type as well: *const c_char for char *, c_int for int, and so on.

// But whereas C and C++ guarantee that a structure’s members appear in mem‐
// ory in the order they’re declared, each at a distinct address, Rust reorders fields to
// minimize the overall size of the struct, and zero-sized types take up no space. The
// #[repr(C)] attribute tells Rust to follow C’s rules for the given type.

#[repr(C)]
#[allow(non_camel_case_types)]
enum git_error_code {
	GIT_OK 				=  0,
	GIT_ERROR 			= -1,
	GIT_ENOTFOUND 		= -3,
	GIT_EEXISTS 		= -4,
	...
}

// Normally, Rust plays all sorts of games when choosing how to represent enums. For
// example, we mentioned the trick Rust uses to store Option<&T> in a single word (if T
// is sized). Without #[repr(C)], Rust would use a single byte to represent the
// git_error_code enum; with #[repr(C)], 

// Rust uses a value the size of a C int, just as C would.

// You can also ask Rust to give an enum the same representation as some integer type.
// Starting the preceding definition with #[repr(i16)] would give you a 16-bit type
// with the same representation as the following C++ enum:

#include <stdint.h>

enum git_error_code: int16_t {
	GIT_OK 				=  0,
	GIT_ERROR 			= -1,
	GIT_ENOTFOUND 		= -3,
	GIT_EEXISTS 		= -4,
	...
}



//______________________________________________________________
// In C Code

int git_libgit2_init() {

}


extern "C" {
	// This Rust API Will Map To C Code
    pub fn git_libgit2_init()       -> c_int;
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fn main() {
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
    // println!("\n\n\nFunction : ");
}

