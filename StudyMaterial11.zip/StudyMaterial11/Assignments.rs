_____________________________________________________________________

DAY 01
_____________________________________________________________________

ENVIRONMENT SETUP
	Please Setup Rust Programming Compilers

	
READING ASSIGNMENT:
	Chapter 02: Types, Operators and Expressions
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie

_____________________________________________________________________

DAY 02
_____________________________________________________________________

ENVIRONMENT SETUP
	Please Setup Rust Programming Compilers

REVISION ASSIGNMENT:
	Practice Code Examples Done Till Now In Class

READING ASSIGNMENT:
	Chapter 02: Types, Operators and Expressions
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie


_____________________________________________________________________

DAY 03
_____________________________________________________________________


REVISION ASSIGNMENT:
	Practice Code Examples Done Till Now In Class

READING ASSIGNMENT:
	Chapter 02: Types, Operators and Expressions
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie

_____________________________________________________________________

DAY 04
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

	2. https://doc.rust-lang.org/std/fmt/

READING ASSIGNMENT:
	Chapter 05: Pointers and Arrays
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie


_____________________________________________________________________

DAY 05
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

	2. https://doc.rust-lang.org/std/fmt/

READING ASSIGNMENT:
	Chapter 05: Pointers and Arrays
		The C Programming Language, 2nd Edition, By Kernighm and Ritchie

_____________________________________________________________________

DAY 06
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

_____________________________________________________________________

DAY 07
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

_____________________________________________________________________

DAY 08
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

_____________________________________________________________________

DAY 09
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class
	2. Revise Code As Well As Rust and C For Quiz

_____________________________________________________________________

DAY 10
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

_____________________________________________________________________

DAY 11
_____________________________________________________________________

READING AND CODING ASSIGNMENT:
	1. Practice Code Examples Done Till Now In Class

_____________________________________________________________________

_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

