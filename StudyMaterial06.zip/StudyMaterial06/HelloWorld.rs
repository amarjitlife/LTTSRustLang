/*
	1. Install Rust Compiler

		A. Install Using rustup Script [ Popular Way Of Installation ]
			
			curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
	
			What curl Command Does?
				It's Dowloads

			| means Pipe

		B. Install Using PreBuild Binaries [Package As Installer]
			e.g. MSI File For Windows
					Installer 

		C. Install Using PreBuild Binaries [Packaged As Compressed File ]

			Compression Format: TAR Format
			1. Download .tar.xz File Compressed Rust Compiler Tool Chain
			e.g.
				rust-1.86.0-x86_64-unknown-linux-gnu.tar.xz	
				i686-pc-windows-msvc 	- With Microsoft Visual C++ Base
				i686-pc-windows-gnu 	- GNU C/C++ Compiler Base For Windows 64 Bit

			2. Uncompress File
					tar -xvf rust-1.86.0-x86_64-unknown-linux-gnu.tar.xz

			3. Will Get Directory/Folder With Rust Compilers and Tool Chains

			4. Setup PATH Variable With Rust Compiler and Cargo Tool Chain
				export PATH="YOUR_EXTRACT_FOLDER/rust-1.86.0-x86_64-unknown-linux-gnu/rustc/bin":$PATH

			5. Exit Command Prompt/Terminal and Launch Again
				rustc --version


	2. Create Hello World Program
	3. Compile and Run Hello World

	// Rust Compilation Command
		rustc HelloWorld.rs -o hello
		./hello


	ALTERNATIVE:
		In Case Your Local Environment Is Not Up Than Use Online Rust Playground
			To Compile and Test Code
		https://play.rust-lang.org/?version=stable&mode=debug&edition=2024
*/

fn main() {
	println!("Hello World!!! Welcome To Rust!!!");
}
