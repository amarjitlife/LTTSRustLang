

fn play_with_scope_again_again(){
    let greeting=String::from("Good Morning");
    println!("Hey:{greeting} {:p}",&greeting);

    let hello=greeting;
    println!("Hey:{hello} {:p}",&hello);

    let greeting="Good Evening";
    println!("Hey:{greeting} {:p}",&greeting);

    let hello=greeting;
    println!("Hey:{hello} {:p}",&hello);
    println!("Hey:{greeting} {:p}",&greeting);
}

