
//_____________________________________________________________

fn play_with_scope() { // Outer Scope Starts
	let greeting = "Good Evening!!!";
	println!("Hey: {greeting}");

	let hello = String::from("Hello More!!!");
	println!("Hey: {hello}");

	{ // Inside/Local Scope Starts
		// Inside Always Take Precedence Over Outer Scope
		//		Identifiers In Inside/Local Scope Shadow Outside/Outer Scope One
		let hello = "Hello!"; // LifeTime Of hello Till Scope Ends
		println!("Hey: {hello}");
	} // Inside/Local Scope Ends

// 	println!("Hey: {hello}");	
// // 14 |     println!("Hey: {hello}");    
// //    |                     ^^^^^ not found in this scope

	// Shadowing Identifiers In Same Scope
	let hello = String::from("Hello Once More!!!");
	println!("Hey: {hello}");

	let hello = 99898;
	println!("Hey: {hello}");

	let hello = String::from("Guten Tag!!!");
	println!("Hey: {hello}");
} // Outer Scope Ends

// Function : play_with_scope
// Hey: Good Evening!!!
// Hey: Hello Once More!!!
// Hey: Hello!

//_____________________________________________________________

fn play_with_scope_again() { // Outer Scope Starts
				// Allocated String Type Object At Heap
				//		greeting Is Refrence To String Type Object At Heap
				//		greeting Is Stored In Stack Frame 
				//				Of Context play_with_scope_again Function
	let greeting = String::from("Guten Tag!!!");
	println!("Hey: {greeting}");

	// 	Reference Assignment With Ownership Shfiting
	//		Ownership Of Object Is Shifted To hello
	// 		greeting Refrence Is Deprecated : No More Exists After This Assignment
	//			greeting Refrence Lifetime Is Over
	//		Hence You Can't Refer Object With greeting Reference
	let hello = greeting; 
	println!("Hey: {hello}");
	// println!("Hey: {greeting}"); // Error: Can't Refer Object With greeting Reference

	// Following Are Allocated At Stack
	let x = 10;
	let y = x; 	// Copy Semantics i.e. It Creates Duplicate Copy

	println!("Value x: {x}");
	println!("Value y: {y}");

	// Following Are Allocated At Stack
	//		String Literal Constant/Immutable i.e. Start and Ends Quotes ""
	let hi = "Hi, How are you?";
	let hiii = hi; // Copy Semantics

	println!("Value hi: {hi}");
	println!("Value hiii: {hiii}");	

	//__________________________________________
	
	let s1 = String::from("Dell Inc.");
	let s2 = s1; // Move Semantics :: Ownership Shifted

	// println!("Company: {s1}");
	println!("Company: {s2}");

	let s11 = String::from("Dell Corporation.");
	let s22 = s11.clone(); 	// Deep Copy i.e. s22 Points To Different Copy Of Object s11

	println!("Company: {s11}");
	println!("Company: {s22}");

} // Outer Scope Ends

//______________________________________________________________

//>>>>>>> DO HANDS ON ABOVE CODE!!! MOMENT DONE RAISE YOUR HAND

//______________________________________________________________
//______________________________________________________________

// Ownership Rules. 
//  1. Each value in Rust has An OWNER
//  2. There can ONLY be ONE OWNER at a time.
//  3. When the owner goes out of scope, the value will be dropped
//			Because Owner Dies Hence Value/Object It Points To Die

// NOTE NOTE::
// 		GENERALLY PROGRAMERS SOLVE LIFE TIME AS A DESIGN:
// 			We need to pair exactly one allocate with exactly one free

// BUT RUST::
//		SOLVES OWNERSHIP FIRST
// 		Rust takes a different path: the memory is automatically 
// 		returned once the variable that owns it goes out of scope. 

// DESIGN PRINCIPLES
//		1. Design Towards Ownership First
//		2. Than Design/Decide Scope
//		3. Life Time Design
//		4. Visibility : Need To Know Basis

//______________________________________________________________

// Here are some of the types that implement Copy:

// All the integer types, such as u32.
// The Boolean type, bool, with values true and false.
// All the floating point types, such as f64.
// The character type, char.
// Tuples, if they only contain types that also implement Copy. 
// 		For example, (i32, i32) implements Copy, 
// 		but (i32, String) does not.

//______________________________________________________________

fn play_with_greeting( some_string : String ) {
	println!("String Value: {some_string}");
}

fn play_with_number( some_number: i32 ) {
	println!("Number Value: {some_number}");	
}

fn play_with_greeting_again( some_string : &str ) {
	println!("String Value: {some_string}");
}

fn play_with_function_arguments() {

	let greeting = String::from("Good Evening!!!");
	let number = 9090;
	// Move Semantics
	//		Ownership Of String Type Object Shifted From greeting To Function Argument
	//			i.e. some_string Is Owner Of String Type Object Now
	play_with_greeting( greeting );

	// println!("String Value: {greeting}"); // Compilation Error: greeting Doesn't Exists

	//	 Copy Semantics 
	play_with_number( number );
	println!("Number Value: {number}");	

	//	 Copy Semantics 
	let greeting_again = "Good Evening!!!";
	play_with_greeting_again( greeting_again );
	println!("String Value: {greeting_again}");
}

//______________________________________________________________


//>>>>>>> DO HANDS ON ABOVE CODE!!! MOMENT DONE RAISE YOUR HAND

//______________________________________________________________


fn play_with_greeting_once_again( some_string : String ) -> String {
	// Function Argument some_string Took Ownership Of String Type Object
	//			From Caller

	// Some Processing... Custome Code...
	println!("String Value: {some_string}");

	// Returing Value As Well As Shifting Ownership To Caller
	// return some_string;
	some_string 	// Equivalent To return some_string;
}

fn say_greeting( ) -> String {
// fn say_greeting() -> () {
// fn say_greeting() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Reference Is Local To Function
	//		greeting Is Ownership Of "Guten Tag" Object Of String Type
	let greeting = String::from("Guten Tag!!!");

	println!("String Value: {greeting}");
	// BY DEFAULT 
	// 		On Exit From Local Scope Of Function/Local Context
	//				Life Time Of Owner is Over i.e. greeting Is Over
	//			 	"Guten Tag" Object Of String Type Is Dropped

	// Returing The Reference As Well As Shifting Ownership To Caller
	greeting 	// Equivalent To return some_string;
}

fn play_with_function_arguments_again() {
	// greeting Reference Has Ownership of "Good Evening!!!" String Type Object
	let greeting = String::from("Good Evening!!!");

	// Rustian Style
	//			Passing greeting Argument To Function
	//					You Are Shifting The Ownership To Function
	//			Function Is Returning String Type Value
	//					You Are Storing Returned Value In greeting
	//					Shifting The Ownership

	//											Move Semantics
	let greeting = play_with_greeting_once_again( greeting );
	println!("String Value: {greeting}");

	// let _ = play_with_greeting_once_again( greeting );

	//											Move Semantics
	let greeting1 = play_with_greeting_once_again( greeting );	
	// println!("String Value: {greeting}");
	// 				^^^^^^^^^^ value borrowed here after move
	println!("String Value: {greeting1}");

	let got_greeting = say_greeting();
	println!("Greeting: {:?}", got_greeting);
}


//______________________________________________________________

fn calculate_length( some_string : &String ) -> usize {
	some_string.len()
	//  Returns the length of this String, in bytes, 
	//	not chars or graphemes. In other words, it might 
	//	not be what a human considers the length of the string

	// Reference Link:
	//		https://doc.rust-lang.org/std/string/struct.String.html#method.len
}

fn play_with_passing_refrences() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Is Have Ownership Of "Guten Tag" Object Of String Type

	let greeting = String::from("Good Evening!!!");

	// Borrow Semantics 
	// Passing Reference Of greeting
	// Passing Reference Of The Object Whose Ownership Lies With Someone Else
	//							greeting Have Ownership
	// 							Ownership Is Not Shifted
	//					Passing Reference Only But Not Shifting Ownership
	//					&greeting Reference Is A Safe Pointer

	let length = calculate_length( &greeting );
	println!("String Length: {length}");
	println!("String Value : {greeting}");
}

//______________________________________________________________

 // Instead, we can provide a Rust reference to the String value. 
 //     A Rust reference is like a pointer in that it’s an address 
 //		we can follow to access the data stored at that address; 

 //     that data is owned by some other variable. 
 
 //    	UNLIKE a Pointer, a referenc is guaranteed to point 
 //     to a valid value of a particular type for the life of 
 //     that reference.

//______________________________________________________________

// When functions have references as parameters instead 
//      of the actual values, we won’t need to return 
//      the values in order to give back ownership, 
//      because we never had ownership.

// We call the action of creating a reference borrowing. As in real life

//______________________________________________________________

// By Default
//		Function Arguments Are IMMUTABLE By Default

fn change_function( mut some_string: &str ) {
	//  some_string = "Hello!!!" // Here some_string Got It's Own Copy Of "Hello" 
// warning: value passed to `some_string` is never read
//		Explains That Arguments To Functions Should Be Used
//		Rather Create Better API Without Unused Arguments
	println!("Value Inside: {some_string}");	

	some_string = "How Are You Doing?";
	//		Above Changes Are Happening Local To This Function
	//			Local Value Of "Hello!!!" Replaced With "How Are You Doing?"	
	// error[E0384]: cannot assign to immutable argument `some_string`
	println!("Value Inside: {some_string}");	
	// some_string Has Ownership 
}

fn play_with_change_data() {
	//	IMMUTABLE By Default
	// warning: variable does not need to be mutable
	// let mut hello = "Hello!!!";
	let hello = "Hello!!!";

	println!("Value Outside: {hello}");
	//		Copy Semantic
	// 			Hence Passed By Value Immergent Behavior Out Of Copy Semantic
	change_function( hello );
	println!("Value Outside: {hello}");
}

// Function : play_with_change_data
// Value Outside: Hello!!!
// Value Inside: Hello!!!
// Value Inside: How Are You Doing?
// Value Outside: Hello!!!


//______________________________________________________________

fn change_function_again( mut some_string: String ) -> String { 
	println!("Value Inside: {some_string}");	

	// Creating Changes/Side Effects
	some_string.push_str(" Mohammed! ");
	println!("Value Inside: {some_string}");
	some_string // Rustian Style Pattern
}

fn play_with_change_function_again() {
	let hello = String::from("Hello");	

	println!("Value Outside: {hello}");	
	//					   Move Semantics
	let hello = change_function_again( hello );
	println!("Value Outside: {hello}");
}

// Function : play_with_change_function_again
// Value Outside: Hello
// Value Inside: Hello
// Value Inside: Hello Mohammed! 

//______________________________________________________________

fn calculate_length_again( some_string : &String ) -> usize {
	some_string.len()
	//  Returns the length of this String, in bytes, 
	//	not chars or graphemes. In other words, it might 
	//	not be what a human considers the length of the string

	// Reference Link:
	//		https://doc.rust-lang.org/std/string/struct.String.html#method.len
}

fn play_with_passing_references() {
	// greeting Is Reference To "Guten Tag" Object Of String Type
	//		greeting Is Have Ownership Of "Guten Tag" Object Of String Type

	//		greeting Is A Data Structure Which Stores Pointer, Len and Capacity
	let greeting = String::from("Hello");
	// Borrow Semantics 
	// Passing Reference Of greeting
	// Passing Reference Of The Object Whose Ownership Lies With Someone Else
	//							greeting Have Ownership
	// 							Ownership Is Not Shifted
	//					Passing Reference Only But Not Shifting Ownership
	//					&greeting Reference Is A Safe Pointer

	let length = calculate_length_again( &greeting );
	println!("String Length: {length}");
	println!("String Value : {greeting}");
}

//______________________________________________________________

// When functions have references as parameters instead 
//      of the actual values, we won’t need to return 
//      the values in order to give back ownership, 
//      because we never had ownership.

// We call the action of creating a reference borrowing. As in real life
//______________________________________________________________

// Borrowing Of Reference and Creating Changes To The Same Object
// fn change_function_once_again( some_string : &mut String ) {

//	Agruments Are Mutable Means 
//		Programmer Specifying This Function Can Create Side Effects

fn change_function_once_again( some_string : &mut String ) {
	some_string.push_str(", World!");
    // |     ^^^^^^^^^^^ `some_string` is a `&` reference, 
    //			so the data it refers to cannot be borrowed as mutable	
}

fn play_with_borrowing() {
	let mut hello = String::from("Hello");

	println!("String Value : {hello}");
	// change_function_once_again( hello );
 	// 		^^^^^ expected `&mut String`, found `String`
	// change_function_once_again( &mut hello );

	// change_function_once_again( &hello );
    // |     --------------------------  ^^^^^^ types differ in mutability
	change_function_once_again( &mut hello );
	println!("String Value : {hello}");
}

//______________________________________________________________

fn play_with_mutable_references() {
	let mut s = String::from("Hello!");

    //Mutable references have one big restriction: 
    // 	if you have a mutable reference to a value
    //  It Must Be Only One Mutable Reference


	let r1 = &mut s;
// println!("Value : {} {}", s, r1 );
//     |                               ^  -- mutable borrow later used here
//     |                               |
//     |                               immutable borrow occurs here	
// 
	let r2 = &mut s;
	// error[E0499]: cannot borrow `s` as mutable more than once at a time
	// 		^^^^^^ second mutable borrow occurs here
	// println!("Value : {} {}", r1, r2 );

	// let mut ss = String::from("Hello!");
   // |         help: remove this `mut`
	let mut ss = String::from("Hello!");

	let r1 = &ss;
	let r2 = &ss;
	let r3 = &ss;
	// let r4 = &mut ss;
	// error[E0502]: cannot borrow `ss` as mutable because it is also borrowed as immutable

	// println!("Value : {} {} {}", r1, r2, r3, r4 );
	println!("Value : {} {} {}", r1, r2, r3 );

	// The restriction preventing multiple mutable references 
	//		to the same data at the same time allows for mutation 
	//		but in a very controlled fashion. 

	// It’s something that new Rustaceans struggle with, because most 
	//		languages let you mutate whenever you’d like. 
	//		The benefit of having this restriction is that Rust can prevent 
	//		data races at compile time. 

	//		A data race is similar to a race condition and 
	//			happens when these three behaviors occur:
			//  1. Two or more pointers access the same data at the same time.
			//  2. At least one of the pointers is being used to write to the data.
			//  3. There’s no mechanism being used to synchronize access to the data.

	let mut ss = String::from("Hello!");
// 		error[E0596]: cannot borrow `ss` as mutable, as it is not declared as mutable

	let r1 = &ss;
	let r2 = &ss;
	let r3 = &ss;

	println!("Value : {} {} {}", r1, r2, r3 );

    // The ability of the compiler to tell that a reference is no 
    // longer being used at a point before the end of the scope 
    //	is called Non-Lexical Lifetimes (NLL for short), 

	let r4 = &mut ss;
	println!("Value : {}", r4 );
	// println!("Value : {} {} {}", r1, r2, r3 );
// 		error[E0502]: cannot borrow `ss` as mutable because 
//				it is also borrowed as immutable

}


//______________________________________________________________

/*
fn dangle_pointer() -> &String {
	// hello Is Owner Of String Type Object "Hello!"
	let hello = String::from("Hello!");

	return &hello // error[E0515]: cannot return reference to local variable `hello`
	// Owner Will Die Moment Function Completes Hence Object Will Also Dies
 	// ^^^^^^ returns a reference to data owned by the current function
}
*/

fn dangle_pointer() -> String {
	let hello = String::from("Hello!");

	return hello // Shifting The Ownership To Caller
}

fn play_with_dangling() {
	// value Will Become Owner Of Returned Object
	let value = dangle_pointer();

	println!("Value: {value}")
}

// Dangling References
// 		In languages with pointers, it’s easy to erroneously 
//		create a dangling pointer--a pointer that references a 
//		location in memory that may have been given to someone else
//		--by freeing some memory while preserving a pointer to that memory. 

// IN RUST LANGUAGE
//		by contrast, the compiler guarantees that references 
//		will never be dangling references: if you have a reference 
///		to some data, the compiler will ensure that the data will 
//		not go out of scope before the reference to the data does.

//______________________________________________________________

// The Rules of References
// 		1.	At any given time, you can have either one mutable reference 
// 		2. 	or any number of immutable references.
// 		3.	References must always be valid.

//______________________________________________________________

fn play_with_slices() {
	// s String Type	
	// RHS String Type Object Created At Heap
	let s: String = String::from("Hello World!"); 
	let len = s.len();
	// Slices From String
	//		Slice :: [start_index..end_index]
	//		start_index is 0 By Default and end_index Is Len By Default

	// hello And world Are Slice Type Hence &str Type
	// IMPORTANT: 
	//	Slices Are Safe Pointers
	//		Because Slice Stores Length Allowed To Be Accessed In Addition To Pointer
	let hello: &str = &s[0..5];
	let world = &s[6..11];

	println!("Value: {s}  Length: {len}");
	println!("Value: {hello}");
	println!("Value: {world}");

	// Following Are Equivalent
	let slice = &s[0..2];
	let slice = &s[..2];
	println!("Value: {slice}");

	let slice = &s[3..len];
	let slice = &s[3..];
	println!("Value: {slice}");

	// Here ss Is A Slice To Binary String
	// let ss = "Hello World!";
	// ss.push_str("Aymen"); 
	// error[E0599]: no method named `push_str` found 
	//	for reference `&str` in the current scope

	// let mut sss = "Hello World!";
	// sss = sss + "Aymen"; // error[E0369]: cannot add `&str` to `&str`
	// println!("Value: {sss}");	

	let ss = "Hello World!";
	let len = ss.len();
	println!("Value: {ss}  Length: {len}");	

    // The type of ss here is &str : it’s a slice pointing to that 
    // specific point of the binary. This is also why string literals 
    // are immutable; &str is an immutable reference.
}

//______________________________________________________________

// BAD CODE
fn first_word( s: &String ) -> usize {
	let bytes = s.as_bytes();

	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return i;
		}
	}

	s.len()
}

fn play_with_first_word() {
	let sentence = String::from("How Are You Doing?");
	// let mut sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word( &sentence );
	println!("Result : {word}");

	// sentence.clear();
	// println!("Sentence : {sentence}");
}

//______________________________________________________________

// Follows Encapsulation
//		It Hides Internal Working Of String and Bytes Buffer
fn first_word_better( s: &String ) -> &str {
	let bytes = s.as_bytes();
	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}
	// s.len()
	&s[..]
}

fn play_with_first_word_better() {
	let sentence = String::from("How Are You Doing?");
	// let mut sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word_better( &sentence );
	println!("Result : {word}");

	// sentence.clear();
	// println!("Sentence : {sentence}");
}

//______________________________________________________________

// RUSTIAN STYLE
//	If we have a string slice, we can pass that directly. 
//	If we have a String , we can pass a slice of the String or a reference to the String . 
//	This flexibility takes advantage of deref coercions,

// Defining a function to take a string slice instead of a reference to a String
// makes our API more general and useful without losing any functionality:

fn first_word_best( s: &str ) -> &str {
	let bytes = s.as_bytes();
	// For In Loop With Enumeration
	//		Generates Sequence Of Tuples (index, value)
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}
	// s.len()
	&s[..]
}

fn play_with_first_word_best() {
	let sentence = String::from("How Are You Doing?");
	// let mut sentence = String::from("How Are You Doing?");

	println!("Sentence : {sentence}");
	let word = first_word_best( &sentence );
	println!("Result : {word}");

	// sentence.clear();
	// println!("Sentence : {sentence}");
}


//______________________________________________________________

fn printing_byte_buffer( s: &str ) {
	let bytes = s.as_bytes();
	for byte in bytes {
		println!(" {byte} ");
	}
}

fn play_with_printing_byte_buffer() {
	// let sentence = String::from("How Are You Doing?");

	let sentence = String::from("How Are You Doing?😊");
	// let mut sentence = String::from("How Are You Doing?");

	printing_byte_buffer( &sentence );
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fn main() {
	println!("\n\n\nFunction : play_with_scope");
	play_with_scope();

	println!("\n\n\nFunction : play_with_scope_again");
	play_with_scope_again();

	println!("\n\n\nFunction : play_with_function_arguments");
	play_with_function_arguments();

	println!("\n\n\nFunction : play_with_function_arguments_again");
	play_with_function_arguments_again();

	println!("\n\n\nFunction : play_with_passing_refrences");
	play_with_passing_refrences();

	println!("\n\n\nFunction : play_with_change_data");
	play_with_change_data();

	println!("\n\n\nFunction : play_with_change_function_again");
	play_with_change_function_again();

	println!("\n\n\nFunction : play_with_passing_references");
	play_with_passing_references();

	println!("\n\n\nFunction : play_with_borrowing");
	play_with_borrowing();

	println!("\n\n\nFunction : play_with_mutable_references");
	play_with_mutable_references();

	println!("\n\n\nFunction : play_with_dangling");
	play_with_dangling();

	println!("\n\n\nFunction : play_with_slices");
	play_with_slices();

	println!("\n\n\nFunction : play_with_first_word");
	play_with_first_word();

	println!("\n\n\nFunction : play_with_first_word_better");
	play_with_first_word_better();

	println!("\n\n\nFunction : play_with_first_word_best");
	play_with_first_word_best();

	println!("\n\n\nFunction : play_with_printing_byte_buffer");
	play_with_printing_byte_buffer();

	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
	// println!("\n\n\nFunction : ");
}

